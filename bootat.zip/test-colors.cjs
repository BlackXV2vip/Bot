const { Telegraf } = require('telegraf');
require('dotenv').config();
const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN);
const testStyles = ['primary', 'secondary', 'danger', 'success', 'destructive', 'blue', 'red', 'green', 'positive', 'negative', 'default', '1', '2', '3'];

async function test() {
  const chatId = '7845383853'; // From server.ts
  for (const style of testStyles) {
    try {
      await bot.telegram.sendMessage(chatId, `Test ${style}`, {
        reply_markup: {
          inline_keyboard: [[{text: 'Test', callback_data: 'test', style: style}]]
        }
      });
      console.log(`Success: ${style}`);
    } catch(e) {
      if (e.description !== "Bad Request: can't parse inline keyboard button: invalid button style specified") {
          console.log(`Failed for ${style} with other error: ${e.description}`);
      }
    }
  }
}
test().then(() => { console.log('Done'); process.exit(0); });
