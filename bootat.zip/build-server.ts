import * as esbuild from 'esbuild';

esbuild.build({
  entryPoints: ['server.ts'],
  bundle: true,
  platform: 'node',
  target: 'node18',
  format: 'esm',
  outfile: 'dist-server/server.mjs',
  external: ['express', 'telegraf', 'better-sqlite3', 'cors', 'vite', 'dotenv'], // Mark native and heavyweight modules as external
}).catch(() => process.exit(1));
